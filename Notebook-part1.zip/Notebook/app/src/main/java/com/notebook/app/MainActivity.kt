package com.notebook.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val BG = Color(0xFFF3EFE8)
private val INK = Color(0xFF2B2622)
private val PALETTE = listOf(
    Color(0xFF8B5E3C), Color(0xFF2F4858), Color(0xFF7A2E3A),
    Color(0xFF3E6B54), Color(0xFFB08D57), Color(0xFF3B3B3B)
)

data class Notebook(val id: Long, val title: String, val color: Int)

object Store {
    private const val PREF = "notebooks"

    fun load(ctx: Context): List<Notebook> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]") ?: "[]"
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Notebook(o.getLong("id"), o.getString("title"), o.getInt("color"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Notebook>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("color", it.color))
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var books by remember { mutableStateOf(Store.load(ctx)) }
    var opened by remember { mutableStateOf<Notebook?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Notebook?>(null) }

    fun update(list: List<Notebook>) {
        books = list
        Store.save(ctx, list)
    }

    val current = opened
    if (current != null) {
        BackHandler { opened = null }
        OpenedPlaceholder(current) { opened = null }
    } else {
        Shelf(
            books = books,
            onOpen = { opened = it },
            onAdd = { showAdd = true },
            onLongPress = { toDelete = it }
        )
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onCreate = { title, color ->
                update(books + Notebook(System.currentTimeMillis(), title, color.toArgb()))
                showAdd = false
            }
        )
    }

    toDelete?.let { nb ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete \"${nb.title}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    update(books.filter { it.id != nb.id })
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Shelf(
    books: List<Notebook>,
    onOpen: (Notebook) -> Unit,
    onAdd: () -> Unit,
    onLongPress: (Notebook) -> Unit
) {
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding()) {
        Text(
            "Notebooks",
            color = INK,
            fontSize = 28.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 4.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalArrangement = Arrangement.spacedBy(36.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(books, key = { it.id }) { nb ->
                Book3D(nb.title, Color(nb.color), Modifier, onClick = { onOpen(nb) }, onLongClick = { onLongPress(nb) })
            }
            item { AddTile(onAdd) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Book3D(
    title: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
    onLongClick: () -> Unit = {}
) {
    val density = LocalDensity.current.density
    val textColor = if (color.luminance() > 0.5f) INK else Color(0xFFF6F2EA)
    val dark = lerp(color, Color.Black, 0.28f)

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .graphicsLayer {
                rotationY = 16f
                cameraDistance = 14f * density
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        // page edges peeking out on the right and bottom
        Box(
            Modifier
                .fillMaxSize()
                .padding(start = 10.dp, top = 4.dp, bottom = 0.dp)
                .background(Color(0xFFF8F4EB), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                .border(0.5.dp, Color(0x22000000), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
        )
        // cover
        Box(
            Modifier
                .fillMaxSize()
                .padding(end = 8.dp, bottom = 4.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp, topEnd = 6.dp, bottomEnd = 6.dp))
                .background(Brush.horizontalGradient(listOf(dark, color, color)))
        ) {
            // spine
            Box(
                Modifier
                    .width(16.dp)
                    .fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(Color(0x66000000), Color(0x00000000))))
            )
            Box(
                Modifier
                    .padding(start = 18.dp)
                    .width(1.dp)
                    .fillMaxHeight()
                    .background(Color(0x22FFFFFF))
            )
            Text(
                title,
                color = textColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(start = 26.dp, end = 12.dp)
            )
        }
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .padding(end = 8.dp, bottom = 4.dp)
            .border(1.5.dp, Color(0x33000000), RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("+", color = Color(0x88000000), fontSize = 36.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onCreate: (String, Color) -> Unit) {
    var title by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(PALETTE[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    placeholder = { Text("Name") }
                )
                Row(
                    Modifier.padding(top = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PALETTE.forEach { c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (c == color) 3.dp else 0.dp,
                                    if (c == color) Color(0xFFB0B0B0) else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(title.trim().ifEmpty { "Untitled" }, color) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun OpenedPlaceholder(nb: Notebook, onBack: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(BG).statusBarsPadding().clickable(onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Book3D(nb.title, Color(nb.color), Modifier.width(160.dp))
            Text(
                "Opening and page flip arrive in part 2",
                color = Color(0x99000000),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 32.dp)
            )
        }
    }
}
