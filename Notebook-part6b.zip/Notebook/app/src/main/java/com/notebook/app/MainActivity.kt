@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.notebook.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DStroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.recognition.Ink
import android.app.Activity
import android.net.Uri
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontFamily
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.math.PI
import kotlin.math.sin
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val BG = Color(0xFFF3EFE8)
private val INK = Color(0xFF2B2622)
private val PAPER = Color(0xFFFBF8F1)
private val PALETTE = listOf(
    Color(0xFF8B5E3C), Color(0xFF2F4858), Color(0xFF7A2E3A),
    Color(0xFF3E6B54), Color(0xFFB08D57), Color(0xFF3B3B3B)
)

// page geometry (dp)
private const val LINE_TOP = 124f
private const val LINE_H = 34f
private const val BOTTOM_PAD = 140f
private const val LINE_BOTTOM = 24f
private const val TEXT_SIZE = 22f
private const val WORD_GAP = 10f
private const val MARGIN_LEFT = 60f
private const val MARGIN_RIGHT = 24f

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t
private fun lineHeightDp(hDp: Float, count: Int) = (hDp - LINE_TOP - LINE_BOTTOM) / max(1, count - 1)
private fun lineCount(hDp: Float) = max(1, ceil((hDp - BOTTOM_PAD - LINE_TOP) / LINE_H).toInt())

private fun hasArabic(s: String) = s.any {
    it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' || it in '\uFB50'..'\uFDFF' || it in '\uFE70'..'\uFEFF'
}

private fun textStyleFor(
    color: Color,
    sizeSp: Float,
    text: String,
    family: FontFamily = FontFamily.Default,
    letterSpacing: Float = 0f
) = TextStyle(
    color = color,
    fontSize = sizeSp.sp,
    fontFamily = family,
    letterSpacing = if (hasArabic(text)) 0.sp else letterSpacing.sp,
    textDirection = if (hasArabic(text)) TextDirection.Rtl else TextDirection.Ltr
)

data class Notebook(val id: Long, val title: String, val color: Int, val pages: Int = 5)

class InkStroke(val color: Int, val width: Float, val pts: FloatArray)

data class TextItem(
    val id: Long,
    val line: Int,
    val x: Float,
    val w: Float,
    val text: String,
    val rtl: Boolean,
    val color: Int,
    val size: Float
)

class Scored(val text: String, val score: Float?)

class ConvState(val page: Int, val itemId: Long, val fromCenter: Offset, val ghosts: List<InkStroke>)

class PageData(val line: Int, val strokes: List<InkStroke>, val texts: List<TextItem>)

data class Cfg(
    val pencilColor: Int = 0xFF3A3A3A.toInt(),
    val pencilWidth: Float = 1.8f,
    val penColor: Int = 0xFF1B2A49.toInt(),
    val penWidth: Float = 2.2f,
    val textColor: Int = 0xFF3A3A3A.toInt(),
    val textSize: Float = 22f,
    val fontPath: String = "",
    val lineColor: Int = 0x1F000000,
    val lineWidth: Float = 1f,
    val showMargin: Boolean = true,
    val showBand: Boolean = true,
    val paper: Int = 0xFFFBF8F1.toInt(),
    val hideStatus: Boolean = true,
    val wordGap: Float = 4f,
    val letterSpacing: Float = 0f,
    val lineCount: Int = 17,
    val recLang: String = "auto"
)

object CfgStore {
    private const val PREF = "cfg"

    fun load(ctx: Context): Cfg {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val d = Cfg()
        return Cfg(
            pencilColor = p.getInt("pencilColor", d.pencilColor),
            pencilWidth = p.getFloat("pencilWidth", d.pencilWidth),
            penColor = p.getInt("penColor", d.penColor),
            penWidth = p.getFloat("penWidth", d.penWidth),
            textColor = p.getInt("textColor", d.textColor),
            textSize = p.getFloat("textSize", d.textSize),
            fontPath = p.getString("fontPath", d.fontPath) ?: "",
            lineColor = p.getInt("lineColor", d.lineColor),
            lineWidth = p.getFloat("lineWidth", d.lineWidth),
            showMargin = p.getBoolean("showMargin", d.showMargin),
            showBand = p.getBoolean("showBand", d.showBand),
            paper = p.getInt("paper", d.paper),
            hideStatus = p.getBoolean("hideStatus", d.hideStatus),
            wordGap = p.getFloat("wordGap", d.wordGap),
            letterSpacing = p.getFloat("letterSpacing", d.letterSpacing),
            lineCount = p.getInt("lineCount", d.lineCount),
            recLang = p.getString("recLang", d.recLang) ?: "auto"
        )
    }

    fun save(ctx: Context, c: Cfg) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putInt("pencilColor", c.pencilColor)
            .putFloat("pencilWidth", c.pencilWidth)
            .putInt("penColor", c.penColor)
            .putFloat("penWidth", c.penWidth)
            .putInt("textColor", c.textColor)
            .putFloat("textSize", c.textSize)
            .putString("fontPath", c.fontPath)
            .putInt("lineColor", c.lineColor)
            .putFloat("lineWidth", c.lineWidth)
            .putBoolean("showMargin", c.showMargin)
            .putBoolean("showBand", c.showBand)
            .putInt("paper", c.paper)
            .putBoolean("hideStatus", c.hideStatus)
            .putFloat("wordGap", c.wordGap)
            .putFloat("letterSpacing", c.letterSpacing)
            .putInt("lineCount", c.lineCount)
            .putString("recLang", c.recLang)
            .apply()
    }
}

object Store {
    private const val PREF = "notebooks"

    fun load(ctx: Context): List<Notebook> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]") ?: "[]"
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Notebook(o.getLong("id"), o.getString("title"), o.getInt("color"), o.optInt("pages", 5))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Notebook>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("color", it.color).put("pages", it.pages)
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", arr.toString()).apply()
    }
}

object InkStore {
    private fun file(ctx: Context, nb: Long, page: Int) = File(ctx.filesDir, "ink_${nb}_$page.json")

    fun load(ctx: Context, nb: Long, page: Int): PageData {
        val f = file(ctx, nb, page)
        if (!f.exists()) return PageData(0, emptyList(), emptyList())
        return try {
            val o = JSONObject(f.readText())
            val arr = o.optJSONArray("strokes") ?: JSONArray()
            val list = (0 until arr.length()).map { i ->
                val s = arr.getJSONObject(i)
                val p = s.getJSONArray("p")
                InkStroke(s.getInt("c"), s.getDouble("w").toFloat(), FloatArray(p.length()) { p.getDouble(it).toFloat() })
            }
            val ta = o.optJSONArray("texts") ?: JSONArray()
            val texts = (0 until ta.length()).map { i ->
                val t = ta.getJSONObject(i)
                TextItem(
                    t.getLong("i"), t.getInt("l"), t.getDouble("x").toFloat(), t.getDouble("w").toFloat(),
                    t.getString("t"), t.getBoolean("r"), t.getInt("c"), t.getDouble("s").toFloat()
                )
            }
            PageData(o.optInt("line", 0), list, texts)
        } catch (e: Exception) {
            PageData(0, emptyList(), emptyList())
        }
    }

    fun save(ctx: Context, nb: Long, page: Int, line: Int, strokes: List<InkStroke>, texts: List<TextItem>) {
        try {
            val arr = JSONArray()
            strokes.forEach { s ->
                val p = JSONArray()
                s.pts.forEach { v -> p.put(Math.round(v * 10f) / 10.0) }
                arr.put(JSONObject().put("c", s.color).put("w", s.width.toDouble()).put("p", p))
            }
            val ta = JSONArray()
            texts.forEach { t ->
                ta.put(
                    JSONObject().put("i", t.id).put("l", t.line).put("x", t.x.toDouble()).put("w", t.w.toDouble())
                        .put("t", t.text).put("r", t.rtl).put("c", t.color).put("s", t.size.toDouble())
                )
            }
            file(ctx, nb, page).writeText(
                JSONObject().put("line", line).put("strokes", arr).put("texts", ta).toString()
            )
        } catch (e: Exception) {
        }
    }

    fun deleteAll(ctx: Context, nb: Long) {
        ctx.filesDir.listFiles { f -> f.name.startsWith("ink_${nb}_") }?.forEach { it.delete() }
    }
}

object ModelNotifier {
    private const val CH = "model_download"
    private const val ID = 4041

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Model download", NotificationManager.IMPORTANCE_LOW))
    }

    fun show(ctx: Context, title: String, text: String, ongoing: Boolean, icon: Int) {
        try {
            ensureChannel(ctx)
            val b = Notification.Builder(ctx.applicationContext, CH)
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setOnlyAlertOnce(true)
            if (ongoing) b.setProgress(0, 0, true)
            ctx.getSystemService(NotificationManager::class.java).notify(ID, b.build())
        } catch (e: Exception) {
        }
    }
}

suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

private fun chain(e: Throwable): String {
    val parts = ArrayList<String>()
    var t: Throwable? = e
    var i = 0
    while (t != null && i < 6) {
        parts.add("${t.javaClass.simpleName}: ${t.message}")
        t = if (t.cause === t) null else t.cause
        i++
    }
    return parts.joinToString(" <- ")
}

/** Handwriting recognition with ML Kit Digital Ink (model is downloaded once, then works offline). */
object Recognizer {
    private val recognizers = HashMap<String, DigitalInkRecognizer>()

    private fun identifier(tag: String): DigitalInkRecognitionModelIdentifier? {
        val tags = if (tag == "fa") listOf("fa", "fa-IR") else listOf(tag)
        for (t in tags) {
            try {
                val id = DigitalInkRecognitionModelIdentifier.fromLanguageTag(t)
                if (id != null) return id
            } catch (e: Exception) {
            }
        }
        return null
    }

    suspend fun recognize(tag: String, strokes: List<FloatArray>, onDownloading: () -> Unit): Scored? {
        val id = identifier(tag) ?: throw IllegalStateException("language not supported")
        val model = DigitalInkRecognitionModel.builder(id).build()
        val mgr = RemoteModelManager.getInstance()
        val downloaded: Boolean = try {
            mgr.isModelDownloaded(model).awaitResult()
        } catch (e: Exception) {
            throw IllegalStateException("[check] " + chain(e), e)
        }
        if (!downloaded) {
            onDownloading()
            try {
                mgr.download(model, DownloadConditions.Builder().build()).awaitResult()
            } catch (e: Exception) {
                throw IllegalStateException("[download] " + chain(e), e)
            }
        }
        val rec = recognizers.getOrPut(tag) {
            DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
        }
        val inkB = Ink.builder()
        var t = 0L
        strokes.forEach { pts ->
            val sb = Ink.Stroke.builder()
            var i = 0
            while (i + 1 < pts.size) {
                sb.addPoint(Ink.Point.create(pts[i], pts[i + 1], t))
                t += 8
                i += 2
            }
            inkB.addStroke(sb.build())
            t += 150
        }
        val res = try {
            rec.recognize(inkB.build()).awaitResult()
        } catch (e: Exception) {
            throw IllegalStateException("[recognize] " + chain(e), e)
        }
        val c = res.candidates.firstOrNull() ?: return null
        return Scored(c.text, c.score)
    }

    /** Runs the Persian and/or English recognizer and returns (text, languageTag) of the best result. */
    suspend fun recognizeAuto(
        mode: String,
        strokes: List<FloatArray>,
        onDownloading: (String) -> Unit
    ): Pair<String, String>? {
        val tags = when (mode) {
            "fa" -> listOf("fa")
            "en" -> listOf("en-US")
            else -> listOf("fa", "en-US")
        }
        var best: Scored? = null
        var bestTag = ""
        var lastError: Exception? = null
        for (tag in tags) {
            try {
                val r = recognize(tag, strokes) { onDownloading(tag) } ?: continue
                if (r.text.isBlank()) continue
                val b = best
                val better = b == null || (r.score != null && (b.score == null || r.score < b.score))
                if (better) {
                    best = r
                    bestTag = tag
                }
            } catch (e: Exception) {
                lastError = e
            }
        }
        val b = best
        if (b == null) {
            val err = lastError
            if (err != null) throw err
            return null
        }
        return Pair(b.text, bestTag)
    }
}

/** Synthesized pencil / pen scratch sound; loudness follows writing speed. */
class ScratchSound {
    @Volatile var target = 0f
    @Volatile var pencil = true
    @Volatile private var running = false
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        try {
            val sr = 22050
            val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sr)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuf, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            running = true
            t.play()
            thread = Thread {
                val buf = ShortArray(512)
                val rnd = java.util.Random()
                var level = 0f
                var lp = 0f
                var prev = 0f
                while (running) {
                    target *= 0.8f
                    level += (target - level) * 0.35f
                    val pen = !pencil
                    for (i in buf.indices) {
                        val w = rnd.nextFloat() * 2f - 1f
                        val s: Float
                        if (!pen) {
                            val h = w - prev
                            prev = w
                            s = h * 0.5f * (0.6f + 0.4f * rnd.nextFloat())
                        } else {
                            lp += 0.18f * (w - lp)
                            s = lp * 1.6f
                        }
                        buf[i] = (s * level * 9000f).toInt().coerceIn(-32000, 32000).toShort()
                    }
                    try {
                        t.write(buf, 0, buf.size)
                    } catch (e: Exception) {
                        break
                    }
                }
            }.also {
                it.isDaemon = true
                it.start()
            }
        } catch (e: Exception) {
            running = false
        }
    }

    fun stop() {
        running = false
        try {
            thread?.join(150)
        } catch (e: Exception) {
        }
        try {
            track?.stop()
            track?.release()
        } catch (e: Exception) {
        }
        track = null
        thread = null
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var books by remember { mutableStateOf(Store.load(ctx)) }
    var cfg by remember { mutableStateOf(CfgStore.load(ctx)) }
    var openedId by remember { mutableStateOf<Long?>(null) }
    var openedRect by remember { mutableStateOf(Rect.Zero) }
    var showAdd by remember { mutableStateOf(false) }
    var menuId by remember { mutableStateOf<Long?>(null) }
    var toDelete by remember { mutableStateOf<Notebook?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(cfg.hideStatus) {
        val w = (ctx as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, w.decorView)
            if (cfg.hideStatus) {
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.statusBars())
            } else {
                c.show(WindowInsetsCompat.Type.statusBars())
            }
        }
    }

    fun update(list: List<Notebook>) {
        books = list
        Store.save(ctx, list)
    }

    fun updateCfg(c: Cfg) {
        cfg = c
        CfgStore.save(ctx, c)
    }

    Box(Modifier.fillMaxSize()) {
        Shelf(
            books = books,
            onOpen = { nb, rect ->
                openedRect = rect
                openedId = nb.id
            },
            onAdd = { showAdd = true },
            onLongPress = { menuId = it.id }
        )

        val opened = books.firstOrNull { it.id == openedId }
        if (opened != null) {
            key(opened.id) {
                Reader(
                    nb = opened,
                    from = openedRect,
                    cfg = cfg,
                    onCfg = { updateCfg(it) },
                    onBack = { openedId = null },
                    onAddPage = {
                        update(books.map { if (it.id == opened.id) it.copy(pages = it.pages + 1) else it })
                    }
                )
            }
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onCreate = { title, color ->
                update(books + Notebook(System.currentTimeMillis(), title, color.toArgb()))
                showAdd = false
            }
        )
    }

    val menuNb = books.firstOrNull { it.id == menuId }
    if (menuNb != null) {
        AlertDialog(
            onDismissRequest = { menuId = null },
            title = { Text(menuNb.title) },
            text = {
                Column {
                    Text("Cover color", fontSize = 13.sp, color = Color(0x99000000))
                    Row(
                        Modifier.padding(top = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        PALETTE.forEach { c ->
                            val sel = c.toArgb() == menuNb.color
                            Box(
                                Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(
                                        if (sel) 3.dp else 0.dp,
                                        if (sel) Color(0xFFB0B0B0) else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable {
                                        update(books.map { if (it.id == menuNb.id) it.copy(color = c.toArgb()) else it })
                                    }
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuId = null }) { Text("Done") } },
            dismissButton = {
                TextButton(onClick = {
                    toDelete = menuNb
                    menuId = null
                }) { Text("Delete") }
            }
        )
    }

    toDelete?.let { nb ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete \"${nb.title}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    InkStore.deleteAll(ctx, nb.id)
                    update(books.filter { it.id != nb.id })
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Shelf(
    books: List<Notebook>,
    onOpen: (Notebook, Rect) -> Unit,
    onAdd: () -> Unit,
    onLongPress: (Notebook) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(BG)
            .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
    ) {
        Text(
            "Notebooks",
            color = INK,
            fontSize = 28.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 4.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalArrangement = Arrangement.spacedBy(36.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(books, key = { it.id }) { nb ->
                Book3D(
                    nb.title, Color(nb.color), Modifier,
                    onClick = { rect -> onOpen(nb, rect) },
                    onLongClick = { onLongPress(nb) }
                )
            }
            item { AddTile(onAdd) }
        }
    }
}

@Composable
fun CoverFace(title: String, color: Color, modifier: Modifier = Modifier, textSize: Float = 16f) {
    val textColor = if (color.luminance() > 0.5f) INK else Color(0xFFF6F2EA)
    val dark = lerp(color, Color.Black, 0.28f)
    Box(modifier.background(Brush.horizontalGradient(listOf(dark, color, color)))) {
        Box(
            Modifier
                .width(16.dp)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Color(0x66000000), Color(0x00000000))))
        )
        Box(
            Modifier
                .padding(start = 18.dp)
                .width(1.dp)
                .fillMaxHeight()
                .background(Color(0x22FFFFFF))
        )
        Text(
            title,
            color = textColor,
            fontSize = textSize.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(start = 26.dp, end = 12.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Book3D(
    title: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (Rect) -> Unit = {},
    onLongClick: () -> Unit = {}
) {
    val density = LocalDensity.current
    var rect by remember { mutableStateOf(Rect.Zero) }

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .onGloballyPositioned { rect = it.boundsInRoot() }
            .graphicsLayer {
                rotationY = 16f
                cameraDistance = 14f * density.density
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .combinedClickable(
                onClick = {
                    val r = rect
                    onClick(
                        Rect(
                            r.left, r.top,
                            r.right - with(density) { 8.dp.toPx() },
                            r.bottom - with(density) { 4.dp.toPx() }
                        )
                    )
                },
                onLongClick = onLongClick
            )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(start = 10.dp, top = 4.dp)
                .background(Color(0xFFF8F4EB), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                .border(0.5.dp, Color(0x22000000), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
        )
        CoverFace(
            title, color,
            Modifier
                .fillMaxSize()
                .padding(end = 8.dp, bottom = 4.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp, topEnd = 6.dp, bottomEnd = 6.dp))
        )
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .padding(end = 8.dp, bottom = 4.dp)
            .border(1.5.dp, Color(0x33000000), RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("+", color = Color(0x88000000), fontSize = 36.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onCreate: (String, Color) -> Unit) {
    var title by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(PALETTE[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    placeholder = { Text("Name") }
                )
                Row(
                    Modifier.padding(top = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PALETTE.forEach { c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (c == color) 3.dp else 0.dp,
                                    if (c == color) Color(0xFFB0B0B0) else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(title.trim().ifEmpty { "Untitled" }, color) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------- Reader

private val INK_COLORS = listOf(
    0xFF3A3A3A.toInt(), 0xFF1B2A49.toInt(), 0xFF111111.toInt(), 0xFF1E4FA3.toInt(),
    0xFFB3261E.toInt(), 0xFF2E7D32.toInt(), 0xFF6D4C41.toInt(), 0xFF6A3FA0.toInt()
)
private val LINE_COLORS = listOf(
    0x1F000000, 0x40000000, 0x554A7FB5, 0x558B5E3C, 0x553E6B54
)
private val PAPER_COLORS = listOf(
    0xFFFBF8F1.toInt(), 0xFFFFFFFF.toInt(), 0xFFF0F0F0.toInt(), 0xFFFFF4CC.toInt(), 0xFFE6F0FA.toInt()
)

class PageStyle(
    val paper: Color,
    val lineColor: Color,
    val lineWidth: Float,
    val showMargin: Boolean,
    val showBand: Boolean,
    val textColor: Color,
    val textSize: Float,
    val fontFamily: FontFamily,
    val letterSpacing: Float,
    val lineCount: Int
)

private fun loadFontFamily(path: String): FontFamily {
    if (path.isEmpty()) return FontFamily.Default
    return try {
        FontFamily(androidx.compose.ui.text.font.Typeface(android.graphics.Typeface.createFromFile(path)))
    } catch (e: Exception) {
        FontFamily.Default
    }
}

private fun importFont(ctx: Context, uri: Uri): String? {
    return try {
        var name = "font"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: "font"
        }
        val lower = name.lowercase()
        if (!lower.endsWith(".ttf") && !lower.endsWith(".otf")) return null
        val dir = File(ctx.filesDir, "fonts")
        dir.mkdirs()
        val dest = File(dir, name.replace("/", "_"))
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        input.use { ins -> dest.outputStream().use { out -> ins.copyTo(out) } }
        dest.absolutePath
    } catch (e: Exception) {
        null
    }
}

// ---------------------------------------------------------------- page curl

private fun pathOf(pts: List<Offset>): Path {
    val p = Path()
    pts.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
    p.close()
    return p
}

/** Part of the page rectangle on one side of a line (point m, normal n). */
private fun clipRectByPlane(
    w: Float, h: Float, mx: Float, my: Float, nx: Float, ny: Float, keepPositive: Boolean
): List<Offset> {
    val pts = listOf(Offset(0f, 0f), Offset(w, 0f), Offset(w, h), Offset(0f, h))
    val out = ArrayList<Offset>()
    fun side(o: Offset): Float {
        val d = (o.x - mx) * nx + (o.y - my) * ny
        return if (keepPositive) d else -d
    }
    for (i in pts.indices) {
        val a = pts[i]
        val b = pts[(i + 1) % pts.size]
        val sa = side(a)
        val sb = side(b)
        if (sa >= 0f) out.add(a)
        if ((sa >= 0f) != (sb >= 0f)) {
            val t = sa / (sa - sb)
            out.add(Offset(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
        }
    }
    return out
}

/**
 * Draws the page with its bottom-right corner folded over, like a real page turn.
 * prog = 0 flat page, prog = 1 page completely turned away to the left.
 * The back of the folded flap is plain paper colored.
 */
private fun ContentDrawScope.drawCurled(prog: Float, paper: Color) {
    val w = size.width
    val h = size.height
    val p = prog.coerceIn(0f, 1f)
    if (p >= 0.999f) return
    // where the dragged corner is now
    val cx = w - p * 2.15f * w
    val cy = h - sin(PI * p).toFloat() * 0.35f * h
    var nx = w - cx
    var ny = h - cy
    val len = sqrt(nx * nx + ny * ny)
    nx /= len
    ny /= len
    val mx = (w + cx) / 2f
    val my = (h + cy) / 2f
    val keep = clipRectByPlane(w, h, mx, my, nx, ny, false)
    val removed = clipRectByPlane(w, h, mx, my, nx, ny, true)
    val fade = ((1f - p) * 6f).coerceIn(0f, 1f)

    // the part of the page that is still flat
    if (keep.size >= 3) {
        clipPath(pathOf(keep)) { this@drawCurled.drawContent() }
    }

    if (removed.size >= 3) {
        // soft shadow of the folding page on the next page
        val sw = 36.dp.toPx()
        drawPath(
            pathOf(removed),
            brush = Brush.linearGradient(
                colors = listOf(Color.Black.copy(alpha = 0.38f * fade), Color.Transparent),
                start = Offset(mx, my),
                end = Offset(mx + nx * sw, my + ny * sw)
            )
        )
        // the folded flap = mirror image of the removed part
        val flapPts = removed.map { o ->
            val d = (o.x - mx) * nx + (o.y - my) * ny
            Offset(o.x - 2f * d * nx, o.y - 2f * d * ny)
        }
        val flapPath = pathOf(flapPts)
        if (keep.size >= 3) {
            clipPath(pathOf(keep)) {
                for (i in 1..6) {
                    drawPath(
                        flapPath,
                        Color.Black.copy(alpha = 0.045f * fade),
                        style = DStroke(width = (i * 5).dp.toPx(), join = StrokeJoin.Round)
                    )
                }
            }
        }
        drawPath(
            flapPath,
            brush = Brush.linearGradient(
                colors = listOf(lerp(paper, Color.Black, 0.2f), paper, lerp(paper, Color.White, 0.6f)),
                start = Offset(mx, my),
                end = Offset(mx - nx * 90.dp.toPx(), my - ny * 90.dp.toPx())
            )
        )
        drawPath(flapPath, Color.Black.copy(alpha = 0.10f), style = DStroke(width = 0.8.dp.toPx()))
    }
}

private fun DrawScope.inkPath(p: FloatArray, color: Color, widthDp: Float) {
    val c = p.size / 2
    if (c == 0) return
    val d = density
    val w = widthDp * d
    if (c == 1) {
        drawCircle(color, w / 2f, Offset(p[0] * d, p[1] * d))
        return
    }
    val path = Path()
    path.moveTo(p[0] * d, p[1] * d)
    for (i in 1 until c) {
        val px = p[2 * (i - 1)] * d
        val py = p[2 * (i - 1) + 1] * d
        val cx = p[2 * i] * d
        val cy = p[2 * i + 1] * d
        path.quadraticBezierTo(px, py, (px + cx) / 2f, (py + cy) / 2f)
    }
    path.lineTo(p[2 * (c - 1)] * d, p[2 * (c - 1) + 1] * d)
    drawPath(path, color, style = DStroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

@Composable
fun PageSheet(
    shade: Float,
    strokes: List<InkStroke>,
    texts: List<TextItem>,
    conv: ConvState?,
    convProgress: () -> Float,
    live: List<Float>?,
    liveColor: Color,
    liveWidth: Float,
    activeLine: Int,
    style: PageStyle,
    modifier: Modifier = Modifier
) {
    val al by animateFloatAsState(activeLine.toFloat(), tween(220), label = "line")
    val measurer = rememberTextMeasurer(cacheSize = 64)
    Box(modifier.fillMaxSize().background(style.paper)) {
        Canvas(Modifier.fillMaxSize()) {
            val d = density
            val lhDp = lineHeightDp(size.height / d, style.lineCount)
            val lineH = lhDp.dp.toPx()
            val top = LINE_TOP.dp.toPx()
            if (style.showBand) {
                drawRect(Color(0x1AB08D57), Offset(0f, top + (al - 1f) * lineH), Size(size.width, lineH))
            }
            for (k in 0 until style.lineCount) {
                val y = top + k * lineH
                drawLine(
                    style.lineColor,
                    Offset(24.dp.toPx(), y),
                    Offset(size.width - 24.dp.toPx(), y),
                    strokeWidth = style.lineWidth.dp.toPx()
                )
            }
            if (style.showMargin) {
                drawLine(
                    Color(0x33C0392B),
                    Offset(52.dp.toPx(), 100.dp.toPx()),
                    Offset(52.dp.toPx(), size.height - LINE_BOTTOM.dp.toPx()),
                    strokeWidth = 1.dp.toPx()
                )
            }
            // converted text
            val prog = convProgress().coerceIn(0f, 1f)
            texts.forEach { item ->
                val eff = min(style.textSize, lhDp * 0.72f)
                val layout = measurer.measure(
                    item.text,
                    textStyleFor(style.textColor, eff, item.text, style.fontFamily, style.letterSpacing)
                )
                val lineY = top + item.line * lineH
                val fx = item.x * d
                val fy = lineY - lineH * 0.2f - layout.firstBaseline
                if (conv != null && conv.itemId == item.id) {
                    val t = FastOutSlowInEasing.transform(prog)
                    val sx = conv.fromCenter.x * d - layout.size.width / 2f
                    val sy = conv.fromCenter.y * d - layout.size.height / 2f
                    drawText(
                        layout,
                        color = style.textColor.copy(alpha = prog),
                        topLeft = Offset(lerpF(sx, fx, t), lerpF(sy, fy, t))
                    )
                } else {
                    drawText(layout, color = style.textColor, topLeft = Offset(fx, fy))
                }
            }
            // ink that is turning into text fades out
            if (conv != null) {
                conv.ghosts.forEach { g ->
                    val c = Color(g.color)
                    inkPath(g.pts, c.copy(alpha = c.alpha * (1f - prog)), g.width)
                }
            }
            strokes.forEach { inkPath(it.pts, Color(it.color), it.width) }
            if (live != null && live.size >= 2) inkPath(live.toFloatArray(), liveColor, liveWidth)
        }
        Box(
            Modifier
                .width(14.dp)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Color(0x22000000), Color(0x00000000))))
        )
        if (shade > 0f) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shade.coerceIn(0f, 1f))))
        }
    }
}

@Composable
fun SegItem(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) INK else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, color = if (selected) PAPER else Color(0xB32B2622))
    }
}

@Composable
fun Seg(a: String, b: String, firstSelected: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x11000000))) {
        SegItem(a, firstSelected) { onChange(true) }
        SegItem(b, !firstSelected) { onChange(false) }
    }
}

@Composable
fun BarButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, color = INK)
    }
}

@Composable
fun TogglePill(text: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (on) INK else Color(0x11000000))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, color = if (on) PAPER else Color(0xB32B2622))
    }
}

@Composable
fun SettingsIcon() {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        val sw = 1.6.dp.toPx()
        val c = Color(0x99000000)
        val ys = listOf(h * 0.2f, h * 0.5f, h * 0.8f)
        val xs = listOf(w * 0.68f, w * 0.30f, w * 0.55f)
        for (i in 0..2) {
            drawLine(c, Offset(0f, ys[i]), Offset(w, ys[i]), strokeWidth = sw, cap = StrokeCap.Round)
            drawCircle(Color(0xFFFBF8F1), 3.4.dp.toPx(), Offset(xs[i], ys[i]))
            drawCircle(c, 3.4.dp.toPx(), Offset(xs[i], ys[i]), style = DStroke(width = sw))
        }
    }
}

@Composable
fun ChevronIcon(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 18.dp, height = 10.dp)) {
        val w = size.width
        val h = size.height
        val sw = 2.dp.toPx()
        val c = Color(0x99000000)
        drawLine(c, Offset(0f, h * 0.15f), Offset(w / 2f, h * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(c, Offset(w, h * 0.15f), Offset(w / 2f, h * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        color = Color(0x99000000),
        modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)
    )
}

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        colors.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .background(Color(c))
                    .border(
                        if (sel) 3.dp else 1.dp,
                        if (sel) Color(0xFF8A8A8A) else Color(0x22000000),
                        CircleShape
                    )
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    live: Boolean,
    resetKey: Any,
    format: (Float) -> String,
    onChange: (Float) -> Unit
) {
    var v by remember(resetKey) { mutableFloatStateOf(value) }
    Column(Modifier.padding(top = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 13.sp, color = INK, modifier = Modifier.weight(1f))
            Text(format(v), fontSize = 13.sp, color = Color(0x99000000))
        }
        Slider(
            value = v,
            onValueChange = {
                v = it
                if (live) onChange(it)
            },
            onValueChangeFinished = { onChange(v) },
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = INK,
                activeTrackColor = INK,
                inactiveTrackColor = Color(0x22000000)
            )
        )
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, color = INK, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = PAPER,
                checkedTrackColor = INK,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0x33000000),
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) INK else Color(0x11000000))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 13.sp, color = if (selected) PAPER else INK)
    }
}

@Composable
fun SettingsPanel(
    cfg: Cfg,
    pencil: Boolean,
    fonts: List<String>,
    onCfg: (Cfg) -> Unit,
    onAddFont: () -> Unit,
    onClose: () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0x66000000))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClose
                )
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .heightIn(max = 620.dp)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFFFFFEFB))
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", fontSize = 18.sp, color = INK, modifier = Modifier.weight(1f))
                Text(
                    "Done",
                    fontSize = 14.sp,
                    color = INK,
                    modifier = Modifier.clickable(onClick = onClose).padding(8.dp)
                )
            }

            SectionTitle("INK  -  " + if (pencil) "PENCIL" else "PEN")
            Swatches(INK_COLORS, if (pencil) cfg.pencilColor else cfg.penColor) { c ->
                onCfg(if (pencil) cfg.copy(pencilColor = c) else cfg.copy(penColor = c))
            }
            LabeledSlider(
                "Thickness", if (pencil) cfg.pencilWidth else cfg.penWidth, 0.8f..6f,
                live = true, resetKey = pencil, format = { "%.1f".format(it) }
            ) { w ->
                onCfg(if (pencil) cfg.copy(pencilWidth = w) else cfg.copy(penWidth = w))
            }

            SectionTitle("CONVERTED TEXT")
            Swatches(INK_COLORS, cfg.textColor) { c -> onCfg(cfg.copy(textColor = c)) }
            LabeledSlider(
                "Size", cfg.textSize, 14f..32f,
                live = false, resetKey = "ts", format = { "%.0f".format(it) }
            ) { s -> onCfg(cfg.copy(textSize = s)) }
            LabeledSlider(
                "Word spacing", cfg.wordGap, 0f..20f,
                live = false, resetKey = "wg", format = { "%.0f".format(it) }
            ) { g -> onCfg(cfg.copy(wordGap = g)) }
            LabeledSlider(
                "Letter spacing (English)", cfg.letterSpacing, -1.5f..4f,
                live = false, resetKey = "ls", format = { "%.1f".format(it) }
            ) { g -> onCfg(cfg.copy(letterSpacing = g)) }
            Row(
                Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip("Default font", cfg.fontPath.isEmpty()) { onCfg(cfg.copy(fontPath = "")) }
                fonts.forEach { path ->
                    Chip(File(path).nameWithoutExtension, cfg.fontPath == path) { onCfg(cfg.copy(fontPath = path)) }
                }
                Chip("+ Add font", false, onAddFont)
            }

            SectionTitle("PAGE")
            Swatches(PAPER_COLORS, cfg.paper) { c -> onCfg(cfg.copy(paper = c)) }
            Box(Modifier.padding(top = 12.dp))
            Swatches(LINE_COLORS, cfg.lineColor) { c -> onCfg(cfg.copy(lineColor = c)) }
            LabeledSlider(
                "Line thickness", cfg.lineWidth, 0.5f..3f,
                live = true, resetKey = "lw", format = { "%.1f".format(it) }
            ) { w -> onCfg(cfg.copy(lineWidth = w)) }
            LabeledSlider(
                "Lines per page", cfg.lineCount.toFloat(), 8f..40f,
                live = false, resetKey = "lc", format = { "%.0f".format(it) }
            ) { c -> onCfg(cfg.copy(lineCount = c.roundToInt())) }
            ToggleRow("Margin line (orange)", cfg.showMargin) { onCfg(cfg.copy(showMargin = it)) }
            ToggleRow("Active line highlight", cfg.showBand) { onCfg(cfg.copy(showBand = it)) }

            SectionTitle("HANDWRITING LANGUAGE")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Auto", cfg.recLang == "auto") { onCfg(cfg.copy(recLang = "auto")) }
                Chip("Persian", cfg.recLang == "fa") { onCfg(cfg.copy(recLang = "fa")) }
                Chip("English", cfg.recLang == "en") { onCfg(cfg.copy(recLang = "en")) }
            }

            SectionTitle("DISPLAY")
            ToggleRow("Hide status bar", cfg.hideStatus) { onCfg(cfg.copy(hideStatus = it)) }
            Box(Modifier.height(12.dp))
        }
    }
}

@Composable
fun Reader(
    nb: Notebook,
    from: Rect,
    cfg: Cfg,
    onCfg: (Cfg) -> Unit,
    onBack: () -> Unit,
    onAddPage: () -> Unit
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val expand = remember { Animatable(0f) }
    val flip = remember { Animatable(0f) }
    var fv by remember { mutableFloatStateOf(0f) }
    var job by remember { mutableStateOf<Job?>(null) }
    var closing by remember { mutableStateOf(false) }
    var lastDir by remember { mutableIntStateOf(1) }
    var prevN by remember { mutableIntStateOf(nb.pages) }
    var writeMode by remember { mutableStateOf(true) }
    var pencil by remember { mutableStateOf(true) }
    var convert by remember { mutableStateOf(true) }
    var typeMode by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var showCount by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    var showSettings by remember { mutableStateOf(false) }
    var barVisible by remember { mutableStateOf(true) }
    var rowsH by remember { mutableIntStateOf(0) }
    val fonts = remember { mutableStateListOf<String>() }
    val ink = remember { mutableStateMapOf<Int, List<InkStroke>>() }
    val lines = remember { mutableStateMapOf<Int, Int>() }
    val texts = remember { mutableStateMapOf<Int, List<TextItem>>() }
    val live = remember { mutableStateListOf<Float>() }
    val pending = remember { ArrayList<InkStroke>() }
    var pendingPage by remember { mutableIntStateOf(-1) }
    var tick by remember { mutableIntStateOf(0) }
    var touching by remember { mutableStateOf(false) }
    var conv by remember { mutableStateOf<ConvState?>(null) }
    val convT = remember { Animatable(0f) }
    var status by remember { mutableStateOf<String?>(null) }
    var sticky by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Pair<Int, TextItem>?>(null) }
    var appliedKey by remember { mutableStateOf("${cfg.textSize}|${cfg.fontPath}|${cfg.wordGap}|${cfg.letterSpacing}|${cfg.lineCount}") }
    val measurer: TextMeasurer = rememberTextMeasurer(cacheSize = 64)
    val sound = remember { ScratchSound() }
    val barP by animateFloatAsState(if (barVisible) 0f else 1f, tween(250), label = "bar")
    val n = nb.pages
    val color = Color(nb.color)
    val cur = fv.roundToInt().coerceIn(0, n - 1)
    val fontFamily = remember(cfg.fontPath) { loadFontFamily(cfg.fontPath) }
    val inkColor = if (pencil) Color(cfg.pencilColor).copy(alpha = 0.85f) else Color(cfg.penColor)
    val inkWidth = if (pencil) cfg.pencilWidth else cfg.penWidth
    val style = PageStyle(
        Color(cfg.paper), Color(cfg.lineColor), cfg.lineWidth, cfg.showMargin, cfg.showBand,
        Color(cfg.textColor), cfg.textSize, fontFamily, cfg.letterSpacing, cfg.lineCount
    )

    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val saved = importFont(ctx, uri)
            if (saved == null) {
                sticky = false
                status = "Pick a .ttf or .otf font file"
            } else {
                if (!fonts.contains(saved)) fonts.add(saved)
                onCfg(cfg.copy(fontPath = saved))
            }
        }
    }

    LaunchedEffect(Unit) {
        expand.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        flip.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }

    LaunchedEffect(Unit) {
        val list = File(ctx.filesDir, "fonts").listFiles()
        if (list != null) {
            list.filter { it.name.lowercase().let { nm -> nm.endsWith(".ttf") || nm.endsWith(".otf") } }
                .sortedBy { it.name }
                .forEach { fonts.add(it.absolutePath) }
        }
    }

    LaunchedEffect(n) {
        for (i in 0 until n) {
            if (!ink.containsKey(i)) {
                val loaded = withContext(Dispatchers.IO) { InkStore.load(ctx, nb.id, i) }
                if (!ink.containsKey(i)) {
                    ink[i] = loaded.strokes
                    lines[i] = loaded.line
                    texts[i] = loaded.texts
                }
            }
        }
    }

    LaunchedEffect(status) {
        val cs = status
        if (cs != null && !sticky) {
            delay(if (cs.startsWith("Model error")) 20000L else 2500L)
            status = null
        }
    }

    DisposableEffect(Unit) {
        sound.start()
        onDispose { sound.stop() }
    }

    fun saveCur(page: Int) {
        InkStore.save(ctx, nb.id, page, lines[page] ?: 0, ink[page] ?: emptyList(), texts[page] ?: emptyList())
    }

    fun goTo(t: Float) {
        job?.cancel()
        job = scope.launch {
            animate(fv, t, animationSpec = tween(380, easing = FastOutSlowInEasing)) { v, _ -> fv = v }
        }
    }

    fun settle(dir: Int) {
        val frac = fv - floor(fv)
        val target = if (dir > 0) {
            if (frac > 0.15f) ceil(fv) else floor(fv)
        } else {
            if (frac < 0.85f) floor(fv) else ceil(fv)
        }
        goTo(target.coerceIn(0f, (n - 1).toFloat()))
    }

    fun undo() {
        val p = fv.roundToInt().coerceIn(0, n - 1)
        val l = ink[p]
        if (!l.isNullOrEmpty()) {
            val removed = l.last()
            ink[p] = l.dropLast(1)
            pending.removeAll { it === removed }
            saveCur(p)
        } else {
            val t = texts[p]
            if (!t.isNullOrEmpty()) {
                texts[p] = t.dropLast(1)
                saveCur(p)
            }
        }
    }

    LaunchedEffect(n) {
        if (n > prevN) {
            job?.cancel()
            animate(fv, (n - 1).toFloat(), animationSpec = tween(350, easing = FastOutSlowInEasing)) { v, _ -> fv = v }
        }
        prevN = n
    }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            flip.animateTo(0f, tween(500, easing = FastOutSlowInEasing))
            expand.animateTo(0f, tween(320, easing = FastOutSlowInEasing))
            onBack()
        }
    }

    BackHandler { close() }
    BackHandler(enabled = showSettings) { showSettings = false }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()
        val wDp = wPx / density.density
        val hDp = hPx / density.density
        val lh = lineHeightDp(hDp, cfg.lineCount)
        val effSize = min(cfg.textSize, lh * 0.72f)

        fun wDpOf(text: String): Float =
            measurer.measure(text, textStyleFor(Color.Black, effSize, text, fontFamily, cfg.letterSpacing)).size.width / density.density

        fun reflow(page: Int, line: Int) {
            val list = texts[page] ?: return
            var x = MARGIN_LEFT
            var re = wDp - MARGIN_RIGHT
            texts[page] = list.map { item ->
                if (item.line != line) {
                    item
                } else if (!item.rtl) {
                    val moved = item.copy(x = x)
                    x += item.w + cfg.wordGap
                    moved
                } else {
                    val nx = re - item.w
                    re = nx - cfg.wordGap
                    item.copy(x = nx)
                }
            }
        }

        fun remeasureAll() {
            val pages = texts.keys.toList()
            for (p in pages) {
                val list = texts[p] ?: continue
                if (list.isEmpty()) continue
                texts[p] = list.map { it.copy(w = wDpOf(it.text)) }
                list.map { it.line }.distinct().forEach { reflow(p, it) }
                saveCur(p)
            }
        }

        LaunchedEffect(cfg.textSize, cfg.fontPath, cfg.wordGap, cfg.letterSpacing, cfg.lineCount) {
            val key = "${cfg.textSize}|${cfg.fontPath}|${cfg.wordGap}|${cfg.letterSpacing}|${cfg.lineCount}"
            if (key != appliedKey) {
                appliedKey = key
                remeasureAll()
            }
        }

        fun placeWord(page: Int, text: String): TextItem {
            val w = wDpOf(text)
            val rtlWord = hasArabic(text)
            val right = wDp - MARGIN_RIGHT
            val maxL = cfg.lineCount - 1
            val all = texts[page] ?: emptyList()
            var line = (lines[page] ?: 0).coerceIn(0, maxL)
            var x = 0f
            var lineRtl = rtlWord
            while (true) {
                val on = all.filter { it.line == line }
                lineRtl = on.firstOrNull()?.rtl ?: rtlWord
                if (!lineRtl) {
                    x = on.maxOfOrNull { it.x + it.w + cfg.wordGap } ?: MARGIN_LEFT
                    if (on.isEmpty() || x + w <= right || line >= maxL) break
                } else {
                    val re = on.minOfOrNull { it.x - cfg.wordGap } ?: right
                    x = re - w
                    if (on.isEmpty() || x >= MARGIN_LEFT || line >= maxL) break
                }
                line++
            }
            lines[page] = line
            return TextItem(System.nanoTime(), line, x, w, text, lineRtl, cfg.textColor, cfg.textSize)
        }

        fun applyEdit(page: Int, item: TextItem, newText: String) {
            val list = texts[page] ?: return
            if (newText.isEmpty()) {
                texts[page] = list.filter { it.id != item.id }
            } else {
                val w = wDpOf(newText)
                texts[page] = list.map { if (it.id == item.id) it.copy(text = newText, w = w) else it }
            }
            reflow(page, item.line)
            saveCur(page)
        }

        fun runConversion() {
            if (!convert || pending.isEmpty() || pendingPage < 0) return
            val page = pendingPage
            val group = pending.toList()
            pending.clear()
            scope.launch {
                var failed = false
                var errMsg = ""
                var downloading = false
                var langName = "Persian"
                val text: String? = try {
                    Recognizer.recognizeAuto(cfg.recLang, group.map { it.pts }) { tag ->
                        langName = if (tag == "fa") "Persian" else "English"
                        status = "Downloading model..."
                        sticky = true
                        downloading = true
                        ModelNotifier.show(
                            ctx, "Downloading handwriting model",
                            "$langName model is downloading. This can take a minute.",
                            true, android.R.drawable.stat_sys_download
                        )
                    }?.first
                } catch (e: Exception) {
                    failed = true
                    errMsg = (e.message ?: e.javaClass.simpleName).take(500)
                    null
                }
                if (sticky) {
                    sticky = false
                    status = null
                }
                if (failed) {
                    status = "Model error: $errMsg"
                    ModelNotifier.show(
                        ctx, "Model download failed", errMsg, false, android.R.drawable.stat_notify_error
                    )
                    return@launch
                }
                if (downloading) {
                    ModelNotifier.show(
                        ctx, "Model ready", "$langName handwriting recognition now works offline.",
                        false, android.R.drawable.stat_sys_download_done
                    )
                }
                val word = text?.trim()
                if (word.isNullOrEmpty()) {
                    status = "Couldn't read that"
                    return@launch
                }
                var minX = Float.MAX_VALUE
                var maxX = -Float.MAX_VALUE
                var minY = Float.MAX_VALUE
                var maxY = -Float.MAX_VALUE
                group.forEach { s ->
                    var i = 0
                    while (i + 1 < s.pts.size) {
                        minX = min(minX, s.pts[i]); maxX = max(maxX, s.pts[i])
                        minY = min(minY, s.pts[i + 1]); maxY = max(maxY, s.pts[i + 1])
                        i += 2
                    }
                }
                ink[page] = (ink[page] ?: emptyList()).filter { s -> group.none { it === s } }
                val item = placeWord(page, word)
                texts[page] = (texts[page] ?: emptyList()) + item
                saveCur(page)
                conv = ConvState(page, item.id, Offset((minX + maxX) / 2f, (minY + maxY) / 2f), group)
                scope.launch {
                    convT.snapTo(0f)
                    convT.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
                    conv = null
                }
            }
        }

        LaunchedEffect(tick) {
            delay(900)
            while (touching) delay(100)
            runConversion()
        }

        fun nextLine() {
            val p = fv.roundToInt().coerceIn(0, n - 1)
            val maxL = cfg.lineCount - 1
            val l = lines[p] ?: 0
            if (l < maxL) {
                lines[p] = l + 1
                saveCur(p)
            } else if (p < n - 1) {
                lines[p + 1] = 0
                goTo((p + 1).toFloat())
            } else {
                onAddPage()
            }
        }

        fun prevLine() {
            val p = fv.roundToInt().coerceIn(0, n - 1)
            val l = lines[p] ?: 0
            if (l > 0) {
                lines[p] = l - 1
                saveCur(p)
            } else if (p > 0) {
                val q = p - 1
                lines[q] = (texts[q] ?: emptyList()).maxOfOrNull { it.line } ?: 0
                saveCur(q)
                goTo(q.toFloat())
            }
        }

        fun hitText(pg: Int, px: Float, py: Float): TextItem? =
            (texts[pg] ?: emptyList()).firstOrNull { t ->
                val yb = LINE_TOP + t.line * lh
                px >= t.x - 4f && px <= t.x + t.w + 4f && py >= yb - lh && py <= yb
            }

        fun commitTyped(word: String) {
            val pg = fv.roundToInt().coerceIn(0, n - 1)
            val item = placeWord(pg, word)
            texts[pg] = (texts[pg] ?: emptyList()) + item
            saveCur(pg)
            conv = ConvState(pg, item.id, Offset(wDp / 2f, hDp - 80f), emptyList())
            scope.launch {
                convT.snapTo(0f)
                convT.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
                conv = null
            }
        }

        fun onTyped(v: String) {
            if (v.contains(' ') || v.contains('\n')) {
                val parts = v.split(' ', '\n')
                parts.dropLast(1).filter { it.isNotBlank() }.forEach { commitTyped(it) }
                typed = parts.last()
            } else {
                typed = v
            }
        }

        fun commitRemainder() {
            val t = typed.trim()
            if (t.isNotEmpty()) commitTyped(t)
            typed = ""
        }

        // pages
        if (flip.value > 0f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(n, writeMode, pencil, convert, inkColor, inkWidth, typeMode, lh) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            val w = size.width.toFloat()
                            val edgeZone = if (writeMode && !typeMode) 28.dp.toPx() else w * 0.25f
                            val edge = down.position.x < edgeZone || down.position.x > w - edgeZone
                            if (!writeMode || edge || typeMode) {
                                // page flip gesture
                                job?.cancel()
                                var acc = 0f
                                var dragging = false
                                val slop = 8.dp.toPx()
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!c.pressed) break
                                    val dx = c.positionChange().x
                                    if (dx != 0f) {
                                        acc += abs(dx)
                                        if (!dragging && acc > slop) dragging = true
                                        if (dragging) {
                                            c.consume()
                                            lastDir = if (dx < 0) 1 else -1
                                            fv = (fv - dx / w).coerceIn(0f, (n - 1).toFloat())
                                        }
                                    }
                                }
                                if (dragging) {
                                    settle(lastDir)
                                } else {
                                    val pg = fv.roundToInt().coerceIn(0, n - 1)
                                    val dd = density.density
                                    val ht = hitText(pg, down.position.x / dd, down.position.y / dd)
                                    if (ht != null) {
                                        editing = Pair(pg, ht)
                                    } else if (down.position.x > w - edgeZone) {
                                        goTo(min(floor(fv) + 1f, (n - 1).toFloat()))
                                    } else if (down.position.x < edgeZone) {
                                        goTo(max(ceil(fv) - 1f, 0f))
                                    }
                                }
                            } else {
                                // writing gesture
                                val d = density.density
                                val page = fv.roundToInt().coerceIn(0, n - 1)
                                sound.pencil = pencil
                                touching = true
                                live.clear()
                                live.add(down.position.x / d)
                                live.add(down.position.y / d)
                                var prevPos = down.position
                                var prevT = down.uptimeMillis
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!c.pressed) {
                                        c.consume()
                                        break
                                    }
                                    if (c.position != prevPos) {
                                        c.consume()
                                        live.add(c.position.x / d)
                                        live.add(c.position.y / d)
                                        val dt = max(1L, c.uptimeMillis - prevT).toFloat()
                                        val dist = (c.position - prevPos).getDistance()
                                        sound.target = (dist / dt / 1.5f).coerceIn(0f, 1f)
                                        prevPos = c.position
                                        prevT = c.uptimeMillis
                                    }
                                }
                                val pts = live.toFloatArray()
                                live.clear()
                                touching = false
                                if (pts.isNotEmpty()) {
                                    // a short tap on converted text opens the editor
                                    var travel = 0f
                                    var i = 2
                                    while (i + 1 < pts.size) {
                                        val ddx = pts[i] - pts[i - 2]
                                        val ddy = pts[i + 1] - pts[i - 1]
                                        travel += sqrt(ddx * ddx + ddy * ddy)
                                        i += 2
                                    }
                                    if (travel < 6f) {
                                        val px = pts[0]
                                        val py = pts[1]
                                        val hit = hitText(page, px, py)
                                        if (hit != null) {
                                            editing = Pair(page, hit)
                                            return@awaitEachGesture
                                        }
                                    }
                                    val stroke = InkStroke(inkColor.toArgb(), inkWidth, pts)
                                    ink[page] = (ink[page] ?: emptyList()) + stroke
                                    saveCur(page)
                                    if (convert) {
                                        if (pendingPage != page) {
                                            pending.clear()
                                            pendingPage = page
                                        }
                                        pending.add(stroke)
                                        tick++
                                    }
                                }
                            }
                        }
                    }
            ) {
                val start = fv.toInt()
                val fr = fv - start
                listOf(start + 1, start).filter { it in 0 until n }.forEach { k ->
                    key(k) {
                        val r = (fv - k).coerceIn(0f, 1f)
                        val cv = conv
                        PageSheet(
                            shade = 0f,
                            strokes = ink[k] ?: emptyList(),
                            texts = texts[k] ?: emptyList(),
                            conv = if (cv != null && cv.page == k) cv else null,
                            convProgress = { convT.value },
                            live = if (k == cur) live else null,
                            liveColor = inkColor,
                            liveWidth = inkWidth,
                            activeLine = lines[k] ?: 0,
                            style = style,
                            modifier = Modifier.drawWithContent {
                                val pr = if (k == start) fv - start else 0f
                                if (pr <= 0.002f) drawContent() else drawCurled(pr, style.paper)
                            }
                        )
                    }
                }
            }
        }

        // cover (flies out of the shelf, then swings open)
        if (flip.value < 1f) {
            val e = expand.value
            val l = lerpF(from.left, 0f, e)
            val t = lerpF(from.top, 0f, e)
            val w = lerpF(from.width, wPx, e)
            val h = lerpF(from.height, hPx, e)
            CoverFace(
                nb.title, color,
                Modifier
                    .offset { IntOffset(l.roundToInt(), t.roundToInt()) }
                    .size(with(density) { w.toDp() }, with(density) { h.toDp() })
                    .graphicsLayer {
                        rotationY = -165f * flip.value
                        cameraDistance = 24f * density.density
                        transformOrigin = TransformOrigin(0f, 0.5f)
                        alpha = if (flip.value * 165f > 90f) 0f else 1f
                    }
                    .clip(RoundedCornerShape(lerpF(6f, 0f, e).dp)),
                textSize = lerpF(16f, 30f, e)
            )
        }

        // top bar (back and add page only)
        val page = min((fv + 0.5f).toInt() + 1, n)
        LaunchedEffect(page) {
            if (flip.value >= 1f) {
                showCount = true
                delay(1000)
                showCount = false
            }
        }
        LaunchedEffect(typeMode) {
            if (typeMode) {
                delay(120)
                try {
                    focus.requestFocus()
                } catch (e: Exception) {
                }
            }
        }
        val countA by animateFloatAsState(if (showCount) 1f else 0f, tween(180), label = "count")
        Row(
            Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                .offset(y = (-14).dp)
                .padding(horizontal = 8.dp)
                .height(48.dp)
                .graphicsLayer { alpha = flip.value },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(48.dp).clickable { close() }, contentAlignment = Alignment.Center) {
                Text("\u2039", fontSize = 32.sp, color = Color(0x99000000))
            }
            Box(Modifier.weight(1f))
            Box(Modifier.size(48.dp).clickable { onAddPage() }, contentAlignment = Alignment.Center) {
                Text("+", fontSize = 26.sp, color = Color(0x99000000))
            }
        }

        // page counter: shown for one second while flipping
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                .padding(top = 4.dp)
                .graphicsLayer { alpha = countA * flip.value }
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x1F000000))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Text("$page / $n", fontSize = 13.sp, color = Color(0xCC000000))
        }

        // status message
        val st = status
        if (st != null) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .padding(top = 52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xE62B2622))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(st, fontSize = 12.sp, color = PAPER)
            }
        }

        // bottom tool bar (with hide / show handle), or the keyboard input bar in Type mode
        val rowsShown = barVisible || barP < 0.98f
        if (!typeMode) {
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 12.dp)
                    .graphicsLayer {
                        alpha = flip.value
                        translationY = if (rowsShown) barP * (rowsH + 6.dp.toPx()) else 0f
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    Modifier
                        .size(width = 52.dp, height = 24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xF2FFFFFF))
                        .border(0.5.dp, Color(0x22000000), RoundedCornerShape(12.dp))
                        .clickable { barVisible = !barVisible },
                    contentAlignment = Alignment.Center
                ) {
                    ChevronIcon(Modifier.graphicsLayer { rotationZ = 180f * barP })
                }
                if (rowsShown) {
                    Column(
                        Modifier
                            .graphicsLayer { alpha = 1f - barP }
                            .onSizeChanged { rowsH = it.height }
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xF2FFFFFF))
                            .border(0.5.dp, Color(0x22000000), RoundedCornerShape(24.dp))
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Seg("Write", "Flip", writeMode) { writeMode = it }
                            Seg("Pencil", "Pen", pencil) { pencil = it }
                            Seg("Hand", "Type", !typeMode) { typeMode = !it }
                            Box(
                                Modifier.size(36.dp).clip(CircleShape).clickable { showSettings = true },
                                contentAlignment = Alignment.Center
                            ) { SettingsIcon() }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                            BarButton("Undo") { undo() }
                            TogglePill("Convert", convert) { convert = !convert }
                            BarButton("Prev line") { prevLine() }
                            BarButton("Next line") { nextLine() }
                        }
                    }
                }
            }
        } else {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .imePadding()
                    .navigationBarsPadding()
                    .padding(10.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xF2FFFFFF))
                    .border(0.5.dp, Color(0x22000000), RoundedCornerShape(24.dp))
                    .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = typed,
                    onValueChange = { onTyped(it) },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 18.sp, color = INK),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        commitRemainder()
                        nextLine()
                    }),
                    modifier = Modifier.weight(1f).focusRequester(focus),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (typed.isEmpty()) {
                                Text("Type, space adds the word", fontSize = 16.sp, color = Color(0x55000000))
                            }
                            inner()
                        }
                    }
                )
                BarButton("Next line") {
                    commitRemainder()
                    nextLine()
                }
                BarButton("Done") {
                    commitRemainder()
                    typeMode = false
                }
            }
        }

        // edit converted text
        editing?.let { ed ->
            val pg = ed.first
            val item = ed.second
            var txt by remember(item.id) { mutableStateOf(item.text) }
            AlertDialog(
                onDismissRequest = { editing = null },
                title = { Text("Edit text") },
                text = { OutlinedTextField(value = txt, onValueChange = { txt = it }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        applyEdit(pg, item, txt.trim())
                        editing = null
                    }) { Text("Save") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            applyEdit(pg, item, "")
                            editing = null
                        }) { Text("Delete") }
                        TextButton(onClick = { editing = null }) { Text("Cancel") }
                    }
                }
            )
        }

        // settings
        if (showSettings) {
            SettingsPanel(
                cfg = cfg,
                pencil = pencil,
                fonts = fonts,
                onCfg = onCfg,
                onAddFont = { fontPicker.launch(arrayOf("*/*")) },
                onClose = { showSettings = false }
            )
        }
    }
}
