package com.notebook.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val BG = Color(0xFFF3EFE8)
private val INK = Color(0xFF2B2622)
private val PAPER = Color(0xFFFBF8F1)
private val PALETTE = listOf(
    Color(0xFF8B5E3C), Color(0xFF2F4858), Color(0xFF7A2E3A),
    Color(0xFF3E6B54), Color(0xFFB08D57), Color(0xFF3B3B3B)
)

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

data class Notebook(val id: Long, val title: String, val color: Int, val pages: Int = 5)

object Store {
    private const val PREF = "notebooks"

    fun load(ctx: Context): List<Notebook> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]") ?: "[]"
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Notebook(o.getLong("id"), o.getString("title"), o.getInt("color"), o.optInt("pages", 5))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Notebook>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("color", it.color).put("pages", it.pages)
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var books by remember { mutableStateOf(Store.load(ctx)) }
    var openedId by remember { mutableStateOf<Long?>(null) }
    var openedRect by remember { mutableStateOf(Rect.Zero) }
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Notebook?>(null) }

    fun update(list: List<Notebook>) {
        books = list
        Store.save(ctx, list)
    }

    Box(Modifier.fillMaxSize()) {
        Shelf(
            books = books,
            onOpen = { nb, rect ->
                openedRect = rect
                openedId = nb.id
            },
            onAdd = { showAdd = true },
            onLongPress = { toDelete = it }
        )

        val opened = books.firstOrNull { it.id == openedId }
        if (opened != null) {
            key(opened.id) {
                Reader(
                    nb = opened,
                    from = openedRect,
                    onBack = { openedId = null },
                    onAddPage = {
                        update(books.map { if (it.id == opened.id) it.copy(pages = it.pages + 1) else it })
                    }
                )
            }
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onCreate = { title, color ->
                update(books + Notebook(System.currentTimeMillis(), title, color.toArgb()))
                showAdd = false
            }
        )
    }

    toDelete?.let { nb ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete \"${nb.title}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    update(books.filter { it.id != nb.id })
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Shelf(
    books: List<Notebook>,
    onOpen: (Notebook, Rect) -> Unit,
    onAdd: () -> Unit,
    onLongPress: (Notebook) -> Unit
) {
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding()) {
        Text(
            "Notebooks",
            color = INK,
            fontSize = 28.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 4.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalArrangement = Arrangement.spacedBy(36.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(books, key = { it.id }) { nb ->
                Book3D(
                    nb.title, Color(nb.color), Modifier,
                    onClick = { rect -> onOpen(nb, rect) },
                    onLongClick = { onLongPress(nb) }
                )
            }
            item { AddTile(onAdd) }
        }
    }
}

@Composable
fun CoverFace(title: String, color: Color, modifier: Modifier = Modifier, textSize: Float = 16f) {
    val textColor = if (color.luminance() > 0.5f) INK else Color(0xFFF6F2EA)
    val dark = lerp(color, Color.Black, 0.28f)
    Box(modifier.background(Brush.horizontalGradient(listOf(dark, color, color)))) {
        Box(
            Modifier
                .width(16.dp)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Color(0x66000000), Color(0x00000000))))
        )
        Box(
            Modifier
                .padding(start = 18.dp)
                .width(1.dp)
                .fillMaxHeight()
                .background(Color(0x22FFFFFF))
        )
        Text(
            title,
            color = textColor,
            fontSize = textSize.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(start = 26.dp, end = 12.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Book3D(
    title: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (Rect) -> Unit = {},
    onLongClick: () -> Unit = {}
) {
    val density = LocalDensity.current
    var rect by remember { mutableStateOf(Rect.Zero) }

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .onGloballyPositioned { rect = it.boundsInRoot() }
            .graphicsLayer {
                rotationY = 16f
                cameraDistance = 14f * density.density
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .combinedClickable(
                onClick = {
                    val r = rect
                    onClick(
                        Rect(
                            r.left, r.top,
                            r.right - with(density) { 8.dp.toPx() },
                            r.bottom - with(density) { 4.dp.toPx() }
                        )
                    )
                },
                onLongClick = onLongClick
            )
    ) {
        // page edges
        Box(
            Modifier
                .fillMaxSize()
                .padding(start = 10.dp, top = 4.dp)
                .background(Color(0xFFF8F4EB), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                .border(0.5.dp, Color(0x22000000), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
        )
        // cover
        CoverFace(
            title, color,
            Modifier
                .fillMaxSize()
                .padding(end = 8.dp, bottom = 4.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp, topEnd = 6.dp, bottomEnd = 6.dp))
        )
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .padding(end = 8.dp, bottom = 4.dp)
            .border(1.5.dp, Color(0x33000000), RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("+", color = Color(0x88000000), fontSize = 36.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onCreate: (String, Color) -> Unit) {
    var title by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(PALETTE[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    placeholder = { Text("Name") }
                )
                Row(
                    Modifier.padding(top = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PALETTE.forEach { c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (c == color) 3.dp else 0.dp,
                                    if (c == color) Color(0xFFB0B0B0) else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(title.trim().ifEmpty { "Untitled" }, color) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------- Reader (part 2)

@Composable
fun PageSheet(index: Int, shade: Float, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(PAPER)) {
        Canvas(Modifier.fillMaxSize()) {
            val lineH = 34.dp.toPx()
            var y = 124.dp.toPx()
            val bottom = size.height - 64.dp.toPx()
            while (y < bottom) {
                drawLine(
                    Color(0x1F000000),
                    Offset(24.dp.toPx(), y),
                    Offset(size.width - 24.dp.toPx(), y),
                    strokeWidth = 1.dp.toPx()
                )
                y += lineH
            }
            drawLine(
                Color(0x33C0392B),
                Offset(52.dp.toPx(), 100.dp.toPx()),
                Offset(52.dp.toPx(), size.height - 40.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
        }
        // binding shadow on the left edge
        Box(
            Modifier
                .width(14.dp)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Color(0x22000000), Color(0x00000000))))
        )
        Text(
            "${index + 1}",
            color = Color(0x66000000),
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp)
        )
        if (shade > 0f) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shade.coerceIn(0f, 1f))))
        }
    }
}

@Composable
fun Reader(nb: Notebook, from: Rect, onBack: () -> Unit, onAddPage: () -> Unit) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val expand = remember { Animatable(0f) }
    val flip = remember { Animatable(0f) }
    var fv by remember { mutableFloatStateOf(0f) }
    var job by remember { mutableStateOf<Job?>(null) }
    var closing by remember { mutableStateOf(false) }
    var lastDir by remember { mutableIntStateOf(1) }
    var prevN by remember { mutableIntStateOf(nb.pages) }
    val n = nb.pages
    val color = Color(nb.color)

    androidx.compose.runtime.LaunchedEffect(Unit) {
        expand.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        flip.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }

    fun goTo(t: Float) {
        job?.cancel()
        job = scope.launch {
            animate(fv, t, animationSpec = tween(300, easing = FastOutSlowInEasing)) { v, _ -> fv = v }
        }
    }

    fun settle(dir: Int) {
        val frac = fv - floor(fv)
        val target = if (dir > 0) {
            if (frac > 0.15f) ceil(fv) else floor(fv)
        } else {
            if (frac < 0.85f) floor(fv) else ceil(fv)
        }
        goTo(target.coerceIn(0f, (n - 1).toFloat()))
    }

    androidx.compose.runtime.LaunchedEffect(n) {
        if (n > prevN) {
            job?.cancel()
            animate(fv, (n - 1).toFloat(), animationSpec = tween(350, easing = FastOutSlowInEasing)) { v, _ -> fv = v }
        }
        prevN = n
    }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            flip.animateTo(0f, tween(500, easing = FastOutSlowInEasing))
            expand.animateTo(0f, tween(320, easing = FastOutSlowInEasing))
            onBack()
        }
    }

    BackHandler { close() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()

        // pages
        if (flip.value > 0f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(n) {
                        detectHorizontalDragGestures(
                            onDragStart = { job?.cancel() },
                            onDragEnd = { settle(lastDir) },
                            onDragCancel = { settle(lastDir) },
                            onHorizontalDrag = { change, dx ->
                                change.consume()
                                lastDir = if (dx < 0) 1 else -1
                                fv = (fv - dx / size.width).coerceIn(0f, (n - 1).toFloat())
                            }
                        )
                    }
                    .pointerInput(n) {
                        detectTapGestures(onTap = { off ->
                            if (off.x > size.width * 0.75f) {
                                goTo(min(floor(fv) + 1f, (n - 1).toFloat()))
                            } else if (off.x < size.width * 0.25f) {
                                goTo(max(ceil(fv) - 1f, 0f))
                            }
                        })
                    }
            ) {
                val start = fv.toInt()
                val fr = fv - start
                listOf(start + 1, start).filter { it in 0 until n }.forEach { k ->
                    key(k) {
                        val r = (fv - k).coerceIn(0f, 1f)
                        val shade = if (k == start) 0.35f * fr else 0.8f * fr * (1f - fr)
                        PageSheet(
                            index = k,
                            shade = shade,
                            modifier = Modifier.graphicsLayer {
                                rotationY = -180f * r
                                cameraDistance = 20f * density.density
                                transformOrigin = TransformOrigin(0f, 0.5f)
                                alpha = if (r > 0.5f) 0f else 1f
                            }
                        )
                    }
                }
            }
        }

        // cover (flies out of the shelf, then swings open)
        if (flip.value < 1f) {
            val e = expand.value
            val l = lerpF(from.left, 0f, e)
            val t = lerpF(from.top, 0f, e)
            val w = lerpF(from.width, wPx, e)
            val h = lerpF(from.height, hPx, e)
            CoverFace(
                nb.title, color,
                Modifier
                    .offset { IntOffset(l.roundToInt(), t.roundToInt()) }
                    .size(with(density) { w.toDp() }, with(density) { h.toDp() })
                    .graphicsLayer {
                        rotationY = -165f * flip.value
                        cameraDistance = 24f * density.density
                        transformOrigin = TransformOrigin(0f, 0.5f)
                        alpha = if (flip.value * 165f > 90f) 0f else 1f
                    }
                    .clip(RoundedCornerShape(lerpF(6f, 0f, e).dp)),
                textSize = lerpF(16f, 30f, e)
            )
        }

        // top bar
        val page = min((fv + 0.5f).toInt() + 1, n)
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp)
                .height(48.dp)
                .graphicsLayer { alpha = flip.value },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(48.dp).clickable { close() }, contentAlignment = Alignment.Center) {
                Text("\u2039", fontSize = 32.sp, color = Color(0x99000000))
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text("$page / $n", fontSize = 13.sp, color = Color(0x99000000))
            }
            Box(Modifier.size(48.dp).clickable { onAddPage() }, contentAlignment = Alignment.Center) {
                Text("+", fontSize = 26.sp, color = Color(0x99000000))
            }
        }
    }
}
