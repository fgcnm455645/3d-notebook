package com.notebook.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DStroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.recognition.Ink
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val BG = Color(0xFFF3EFE8)
private val INK = Color(0xFF2B2622)
private val PAPER = Color(0xFFFBF8F1)
private val PALETTE = listOf(
    Color(0xFF8B5E3C), Color(0xFF2F4858), Color(0xFF7A2E3A),
    Color(0xFF3E6B54), Color(0xFFB08D57), Color(0xFF3B3B3B)
)

// page geometry (dp)
private const val LINE_TOP = 124f
private const val LINE_H = 34f
private const val BOTTOM_PAD = 140f
private const val TEXT_SIZE = 22f
private const val WORD_GAP = 10f
private const val MARGIN_LEFT = 60f
private const val MARGIN_RIGHT = 24f

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t
private fun lineCount(hDp: Float) = max(1, ceil((hDp - BOTTOM_PAD - LINE_TOP) / LINE_H).toInt())

private fun hasArabic(s: String) = s.any {
    it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' || it in '\uFB50'..'\uFDFF' || it in '\uFE70'..'\uFEFF'
}

private fun textStyleFor(color: Color, sizeSp: Float, text: String) = TextStyle(
    color = color,
    fontSize = sizeSp.sp,
    textDirection = if (hasArabic(text)) TextDirection.Rtl else TextDirection.Ltr
)

data class Notebook(val id: Long, val title: String, val color: Int, val pages: Int = 5)

class InkStroke(val color: Int, val width: Float, val pts: FloatArray)

data class TextItem(
    val id: Long,
    val line: Int,
    val x: Float,
    val w: Float,
    val text: String,
    val rtl: Boolean,
    val color: Int,
    val size: Float
)

class ConvState(val page: Int, val itemId: Long, val fromCenter: Offset, val ghosts: List<InkStroke>)

class PageData(val line: Int, val strokes: List<InkStroke>, val texts: List<TextItem>)

object Store {
    private const val PREF = "notebooks"

    fun load(ctx: Context): List<Notebook> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]") ?: "[]"
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Notebook(o.getLong("id"), o.getString("title"), o.getInt("color"), o.optInt("pages", 5))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Notebook>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("color", it.color).put("pages", it.pages)
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", arr.toString()).apply()
    }
}

object InkStore {
    private fun file(ctx: Context, nb: Long, page: Int) = File(ctx.filesDir, "ink_${nb}_$page.json")

    fun load(ctx: Context, nb: Long, page: Int): PageData {
        val f = file(ctx, nb, page)
        if (!f.exists()) return PageData(0, emptyList(), emptyList())
        return try {
            val o = JSONObject(f.readText())
            val arr = o.optJSONArray("strokes") ?: JSONArray()
            val list = (0 until arr.length()).map { i ->
                val s = arr.getJSONObject(i)
                val p = s.getJSONArray("p")
                InkStroke(s.getInt("c"), s.getDouble("w").toFloat(), FloatArray(p.length()) { p.getDouble(it).toFloat() })
            }
            val ta = o.optJSONArray("texts") ?: JSONArray()
            val texts = (0 until ta.length()).map { i ->
                val t = ta.getJSONObject(i)
                TextItem(
                    t.getLong("i"), t.getInt("l"), t.getDouble("x").toFloat(), t.getDouble("w").toFloat(),
                    t.getString("t"), t.getBoolean("r"), t.getInt("c"), t.getDouble("s").toFloat()
                )
            }
            PageData(o.optInt("line", 0), list, texts)
        } catch (e: Exception) {
            PageData(0, emptyList(), emptyList())
        }
    }

    fun save(ctx: Context, nb: Long, page: Int, line: Int, strokes: List<InkStroke>, texts: List<TextItem>) {
        try {
            val arr = JSONArray()
            strokes.forEach { s ->
                val p = JSONArray()
                s.pts.forEach { v -> p.put(Math.round(v * 10f) / 10.0) }
                arr.put(JSONObject().put("c", s.color).put("w", s.width.toDouble()).put("p", p))
            }
            val ta = JSONArray()
            texts.forEach { t ->
                ta.put(
                    JSONObject().put("i", t.id).put("l", t.line).put("x", t.x.toDouble()).put("w", t.w.toDouble())
                        .put("t", t.text).put("r", t.rtl).put("c", t.color).put("s", t.size.toDouble())
                )
            }
            file(ctx, nb, page).writeText(
                JSONObject().put("line", line).put("strokes", arr).put("texts", ta).toString()
            )
        } catch (e: Exception) {
        }
    }

    fun deleteAll(ctx: Context, nb: Long) {
        ctx.filesDir.listFiles { f -> f.name.startsWith("ink_${nb}_") }?.forEach { it.delete() }
    }
}

object ModelNotifier {
    private const val CH = "model_download"
    private const val ID = 4041

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Model download", NotificationManager.IMPORTANCE_LOW))
    }

    fun show(ctx: Context, title: String, text: String, ongoing: Boolean, icon: Int) {
        try {
            ensureChannel(ctx)
            val b = Notification.Builder(ctx.applicationContext, CH)
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setOnlyAlertOnce(true)
            if (ongoing) b.setProgress(0, 0, true)
            ctx.getSystemService(NotificationManager::class.java).notify(ID, b.build())
        } catch (e: Exception) {
        }
    }
}

suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

private fun chain(e: Throwable): String {
    val parts = ArrayList<String>()
    var t: Throwable? = e
    var i = 0
    while (t != null && i < 6) {
        parts.add("${t.javaClass.simpleName}: ${t.message}")
        t = if (t.cause === t) null else t.cause
        i++
    }
    return parts.joinToString(" <- ")
}

/** Handwriting recognition with ML Kit Digital Ink (model is downloaded once, then works offline). */
object Recognizer {
    private val recognizers = HashMap<String, DigitalInkRecognizer>()

    private fun identifier(tag: String): DigitalInkRecognitionModelIdentifier? {
        val tags = if (tag == "fa") listOf("fa", "fa-IR") else listOf(tag)
        for (t in tags) {
            try {
                val id = DigitalInkRecognitionModelIdentifier.fromLanguageTag(t)
                if (id != null) return id
            } catch (e: Exception) {
            }
        }
        return null
    }

    suspend fun recognize(tag: String, strokes: List<FloatArray>, onDownloading: () -> Unit): String? {
        val id = identifier(tag) ?: throw IllegalStateException("language not supported")
        val model = DigitalInkRecognitionModel.builder(id).build()
        val mgr = RemoteModelManager.getInstance()
        val downloaded: Boolean = try {
            mgr.isModelDownloaded(model).awaitResult()
        } catch (e: Exception) {
            throw IllegalStateException("[check] " + chain(e), e)
        }
        if (!downloaded) {
            onDownloading()
            try {
                mgr.download(model, DownloadConditions.Builder().build()).awaitResult()
            } catch (e: Exception) {
                throw IllegalStateException("[download] " + chain(e), e)
            }
        }
        val rec = recognizers.getOrPut(tag) {
            DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
        }
        val inkB = Ink.builder()
        var t = 0L
        strokes.forEach { pts ->
            val sb = Ink.Stroke.builder()
            var i = 0
            while (i + 1 < pts.size) {
                sb.addPoint(Ink.Point.create(pts[i], pts[i + 1], t))
                t += 8
                i += 2
            }
            inkB.addStroke(sb.build())
            t += 150
        }
        val res = try {
            rec.recognize(inkB.build()).awaitResult()
        } catch (e: Exception) {
            throw IllegalStateException("[recognize] " + chain(e), e)
        }
        return res.candidates.firstOrNull()?.text
    }
}

/** Synthesized pencil / pen scratch sound; loudness follows writing speed. */
class ScratchSound {
    @Volatile var target = 0f
    @Volatile var pencil = true
    @Volatile private var running = false
    private var track: AudioTrack? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        try {
            val sr = 22050
            val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sr)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuf, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            running = true
            t.play()
            thread = Thread {
                val buf = ShortArray(512)
                val rnd = java.util.Random()
                var level = 0f
                var lp = 0f
                var prev = 0f
                while (running) {
                    target *= 0.8f
                    level += (target - level) * 0.35f
                    val pen = !pencil
                    for (i in buf.indices) {
                        val w = rnd.nextFloat() * 2f - 1f
                        val s: Float
                        if (!pen) {
                            val h = w - prev
                            prev = w
                            s = h * 0.5f * (0.6f + 0.4f * rnd.nextFloat())
                        } else {
                            lp += 0.18f * (w - lp)
                            s = lp * 1.6f
                        }
                        buf[i] = (s * level * 9000f).toInt().coerceIn(-32000, 32000).toShort()
                    }
                    try {
                        t.write(buf, 0, buf.size)
                    } catch (e: Exception) {
                        break
                    }
                }
            }.also {
                it.isDaemon = true
                it.start()
            }
        } catch (e: Exception) {
            running = false
        }
    }

    fun stop() {
        running = false
        try {
            thread?.join(150)
        } catch (e: Exception) {
        }
        try {
            track?.stop()
            track?.release()
        } catch (e: Exception) {
        }
        track = null
        thread = null
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var books by remember { mutableStateOf(Store.load(ctx)) }
    var openedId by remember { mutableStateOf<Long?>(null) }
    var openedRect by remember { mutableStateOf(Rect.Zero) }
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Notebook?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun update(list: List<Notebook>) {
        books = list
        Store.save(ctx, list)
    }

    Box(Modifier.fillMaxSize()) {
        Shelf(
            books = books,
            onOpen = { nb, rect ->
                openedRect = rect
                openedId = nb.id
            },
            onAdd = { showAdd = true },
            onLongPress = { toDelete = it }
        )

        val opened = books.firstOrNull { it.id == openedId }
        if (opened != null) {
            key(opened.id) {
                Reader(
                    nb = opened,
                    from = openedRect,
                    onBack = { openedId = null },
                    onAddPage = {
                        update(books.map { if (it.id == opened.id) it.copy(pages = it.pages + 1) else it })
                    }
                )
            }
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onCreate = { title, color ->
                update(books + Notebook(System.currentTimeMillis(), title, color.toArgb()))
                showAdd = false
            }
        )
    }

    toDelete?.let { nb ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete \"${nb.title}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    InkStore.deleteAll(ctx, nb.id)
                    update(books.filter { it.id != nb.id })
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Shelf(
    books: List<Notebook>,
    onOpen: (Notebook, Rect) -> Unit,
    onAdd: () -> Unit,
    onLongPress: (Notebook) -> Unit
) {
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding()) {
        Text(
            "Notebooks",
            color = INK,
            fontSize = 28.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 4.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalArrangement = Arrangement.spacedBy(36.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(books, key = { it.id }) { nb ->
                Book3D(
                    nb.title, Color(nb.color), Modifier,
                    onClick = { rect -> onOpen(nb, rect) },
                    onLongClick = { onLongPress(nb) }
                )
            }
            item { AddTile(onAdd) }
        }
    }
}

@Composable
fun CoverFace(title: String, color: Color, modifier: Modifier = Modifier, textSize: Float = 16f) {
    val textColor = if (color.luminance() > 0.5f) INK else Color(0xFFF6F2EA)
    val dark = lerp(color, Color.Black, 0.28f)
    Box(modifier.background(Brush.horizontalGradient(listOf(dark, color, color)))) {
        Box(
            Modifier
                .width(16.dp)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Color(0x66000000), Color(0x00000000))))
        )
        Box(
            Modifier
                .padding(start = 18.dp)
                .width(1.dp)
                .fillMaxHeight()
                .background(Color(0x22FFFFFF))
        )
        Text(
            title,
            color = textColor,
            fontSize = textSize.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(start = 26.dp, end = 12.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Book3D(
    title: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (Rect) -> Unit = {},
    onLongClick: () -> Unit = {}
) {
    val density = LocalDensity.current
    var rect by remember { mutableStateOf(Rect.Zero) }

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .onGloballyPositioned { rect = it.boundsInRoot() }
            .graphicsLayer {
                rotationY = 16f
                cameraDistance = 14f * density.density
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .combinedClickable(
                onClick = {
                    val r = rect
                    onClick(
                        Rect(
                            r.left, r.top,
                            r.right - with(density) { 8.dp.toPx() },
                            r.bottom - with(density) { 4.dp.toPx() }
                        )
                    )
                },
                onLongClick = onLongClick
            )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(start = 10.dp, top = 4.dp)
                .background(Color(0xFFF8F4EB), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                .border(0.5.dp, Color(0x22000000), RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
        )
        CoverFace(
            title, color,
            Modifier
                .fillMaxSize()
                .padding(end = 8.dp, bottom = 4.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp, topEnd = 6.dp, bottomEnd = 6.dp))
        )
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .padding(end = 8.dp, bottom = 4.dp)
            .border(1.5.dp, Color(0x33000000), RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("+", color = Color(0x88000000), fontSize = 36.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onCreate: (String, Color) -> Unit) {
    var title by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(PALETTE[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    placeholder = { Text("Name") }
                )
                Row(
                    Modifier.padding(top = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PALETTE.forEach { c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (c == color) 3.dp else 0.dp,
                                    if (c == color) Color(0xFFB0B0B0) else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(title.trim().ifEmpty { "Untitled" }, color) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------- Reader

private fun DrawScope.inkPath(p: FloatArray, color: Color, widthDp: Float) {
    val c = p.size / 2
    if (c == 0) return
    val d = density
    val w = widthDp * d
    if (c == 1) {
        drawCircle(color, w / 2f, Offset(p[0] * d, p[1] * d))
        return
    }
    val path = Path()
    path.moveTo(p[0] * d, p[1] * d)
    for (i in 1 until c) {
        val px = p[2 * (i - 1)] * d
        val py = p[2 * (i - 1) + 1] * d
        val cx = p[2 * i] * d
        val cy = p[2 * i + 1] * d
        path.quadraticBezierTo(px, py, (px + cx) / 2f, (py + cy) / 2f)
    }
    path.lineTo(p[2 * (c - 1)] * d, p[2 * (c - 1) + 1] * d)
    drawPath(path, color, style = DStroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

@Composable
fun PageSheet(
    shade: Float,
    strokes: List<InkStroke>,
    texts: List<TextItem>,
    conv: ConvState?,
    convProgress: () -> Float,
    live: List<Float>?,
    liveColor: Color,
    liveWidth: Float,
    activeLine: Int,
    modifier: Modifier = Modifier
) {
    val al by animateFloatAsState(activeLine.toFloat(), tween(220), label = "line")
    val measurer = rememberTextMeasurer(cacheSize = 64)
    Box(modifier.fillMaxSize().background(PAPER)) {
        Canvas(Modifier.fillMaxSize()) {
            val d = density
            val lineH = LINE_H.dp.toPx()
            val top = LINE_TOP.dp.toPx()
            val bottom = size.height - BOTTOM_PAD.dp.toPx()
            // active line highlight
            drawRect(Color(0x1AB08D57), Offset(0f, top + (al - 1f) * lineH), Size(size.width, lineH))
            var y = top
            while (y < bottom) {
                drawLine(
                    Color(0x1F000000),
                    Offset(24.dp.toPx(), y),
                    Offset(size.width - 24.dp.toPx(), y),
                    strokeWidth = 1.dp.toPx()
                )
                y += lineH
            }
            drawLine(
                Color(0x33C0392B),
                Offset(52.dp.toPx(), 100.dp.toPx()),
                Offset(52.dp.toPx(), size.height - 90.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
            // converted text
            val prog = convProgress().coerceIn(0f, 1f)
            texts.forEach { item ->
                val layout = measurer.measure(item.text, textStyleFor(Color(item.color), item.size, item.text))
                val lineY = top + item.line * lineH
                val fx = item.x * d
                val fy = lineY - 7.dp.toPx() - layout.firstBaseline
                if (conv != null && conv.itemId == item.id) {
                    val t = FastOutSlowInEasing.transform(prog)
                    val sx = conv.fromCenter.x * d - layout.size.width / 2f
                    val sy = conv.fromCenter.y * d - layout.size.height / 2f
                    drawText(
                        layout,
                        color = Color(item.color).copy(alpha = prog),
                        topLeft = Offset(lerpF(sx, fx, t), lerpF(sy, fy, t))
                    )
                } else {
                    drawText(layout, color = Color(item.color), topLeft = Offset(fx, fy))
                }
            }
            // ink that is turning into text fades out
            if (conv != null) {
                conv.ghosts.forEach { g ->
                    val c = Color(g.color)
                    inkPath(g.pts, c.copy(alpha = c.alpha * (1f - prog)), g.width)
                }
            }
            strokes.forEach { inkPath(it.pts, Color(it.color), it.width) }
            if (live != null && live.size >= 2) inkPath(live.toFloatArray(), liveColor, liveWidth)
        }
        Box(
            Modifier
                .width(14.dp)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Color(0x22000000), Color(0x00000000))))
        )
        if (shade > 0f) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shade.coerceIn(0f, 1f))))
        }
    }
}

@Composable
fun SegItem(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) INK else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, color = if (selected) PAPER else Color(0xB32B2622))
    }
}

@Composable
fun Seg(a: String, b: String, firstSelected: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x11000000))) {
        SegItem(a, firstSelected) { onChange(true) }
        SegItem(b, !firstSelected) { onChange(false) }
    }
}

@Composable
fun BarButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, color = INK)
    }
}

@Composable
fun TogglePill(text: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (on) INK else Color(0x11000000))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 12.sp, color = if (on) PAPER else Color(0xB32B2622))
    }
}

@Composable
fun Reader(nb: Notebook, from: Rect, onBack: () -> Unit, onAddPage: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val expand = remember { Animatable(0f) }
    val flip = remember { Animatable(0f) }
    var fv by remember { mutableFloatStateOf(0f) }
    var job by remember { mutableStateOf<Job?>(null) }
    var closing by remember { mutableStateOf(false) }
    var lastDir by remember { mutableIntStateOf(1) }
    var prevN by remember { mutableIntStateOf(nb.pages) }
    var writeMode by remember { mutableStateOf(true) }
    var pencil by remember { mutableStateOf(true) }
    var convert by remember { mutableStateOf(true) }
    var lang by remember { mutableStateOf("fa") }
    val ink = remember { mutableStateMapOf<Int, List<InkStroke>>() }
    val lines = remember { mutableStateMapOf<Int, Int>() }
    val texts = remember { mutableStateMapOf<Int, List<TextItem>>() }
    val live = remember { mutableStateListOf<Float>() }
    val pending = remember { ArrayList<InkStroke>() }
    var pendingPage by remember { mutableIntStateOf(-1) }
    var tick by remember { mutableIntStateOf(0) }
    var touching by remember { mutableStateOf(false) }
    var conv by remember { mutableStateOf<ConvState?>(null) }
    val convT = remember { Animatable(0f) }
    var status by remember { mutableStateOf<String?>(null) }
    var sticky by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Pair<Int, TextItem>?>(null) }
    val measurer: TextMeasurer = rememberTextMeasurer(cacheSize = 64)
    val sound = remember { ScratchSound() }
    val n = nb.pages
    val color = Color(nb.color)
    val cur = fv.roundToInt().coerceIn(0, n - 1)
    val inkColor = if (pencil) Color(0xD93A3A3A) else Color(0xFF1B2A49)
    val inkWidth = if (pencil) 1.8f else 2.2f

    LaunchedEffect(Unit) {
        expand.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        flip.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }

    LaunchedEffect(n) {
        for (i in 0 until n) {
            if (!ink.containsKey(i)) {
                val loaded = withContext(Dispatchers.IO) { InkStore.load(ctx, nb.id, i) }
                if (!ink.containsKey(i)) {
                    ink[i] = loaded.strokes
                    lines[i] = loaded.line
                    texts[i] = loaded.texts
                }
            }
        }
    }

    LaunchedEffect(status) {
        val cs = status
        if (cs != null && !sticky) {
            delay(if (cs.startsWith("Model error")) 20000L else 2500L)
            status = null
        }
    }

    DisposableEffect(Unit) {
        sound.start()
        onDispose { sound.stop() }
    }

    fun saveCur(page: Int) {
        InkStore.save(ctx, nb.id, page, lines[page] ?: 0, ink[page] ?: emptyList(), texts[page] ?: emptyList())
    }

    fun goTo(t: Float) {
        job?.cancel()
        job = scope.launch {
            animate(fv, t, animationSpec = tween(300, easing = FastOutSlowInEasing)) { v, _ -> fv = v }
        }
    }

    fun settle(dir: Int) {
        val frac = fv - floor(fv)
        val target = if (dir > 0) {
            if (frac > 0.15f) ceil(fv) else floor(fv)
        } else {
            if (frac < 0.85f) floor(fv) else ceil(fv)
        }
        goTo(target.coerceIn(0f, (n - 1).toFloat()))
    }

    fun undo() {
        val p = fv.roundToInt().coerceIn(0, n - 1)
        val l = ink[p]
        if (!l.isNullOrEmpty()) {
            val removed = l.last()
            ink[p] = l.dropLast(1)
            pending.removeAll { it === removed }
            saveCur(p)
        } else {
            val t = texts[p]
            if (!t.isNullOrEmpty()) {
                texts[p] = t.dropLast(1)
                saveCur(p)
            }
        }
    }

    LaunchedEffect(n) {
        if (n > prevN) {
            job?.cancel()
            animate(fv, (n - 1).toFloat(), animationSpec = tween(350, easing = FastOutSlowInEasing)) { v, _ -> fv = v }
        }
        prevN = n
    }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            flip.animateTo(0f, tween(500, easing = FastOutSlowInEasing))
            expand.animateTo(0f, tween(320, easing = FastOutSlowInEasing))
            onBack()
        }
    }

    BackHandler { close() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()
        val wDp = wPx / density.density
        val hDp = hPx / density.density

        fun wDpOf(text: String): Float =
            measurer.measure(text, textStyleFor(Color.Black, TEXT_SIZE, text)).size.width / density.density

        fun reflow(page: Int, line: Int) {
            val list = texts[page] ?: return
            var x = MARGIN_LEFT
            var re = wDp - MARGIN_RIGHT
            texts[page] = list.map { item ->
                if (item.line != line) {
                    item
                } else if (!item.rtl) {
                    val moved = item.copy(x = x)
                    x += item.w + WORD_GAP
                    moved
                } else {
                    val nx = re - item.w
                    re = nx - WORD_GAP
                    item.copy(x = nx)
                }
            }
        }

        fun placeWord(page: Int, text: String, colorInt: Int): TextItem {
            val w = wDpOf(text)
            val rtlWord = hasArabic(text)
            val right = wDp - MARGIN_RIGHT
            val maxL = lineCount(hDp) - 1
            val all = texts[page] ?: emptyList()
            var line = (lines[page] ?: 0).coerceIn(0, maxL)
            var x = 0f
            var lineRtl = rtlWord
            while (true) {
                val on = all.filter { it.line == line }
                lineRtl = on.firstOrNull()?.rtl ?: rtlWord
                if (!lineRtl) {
                    x = on.maxOfOrNull { it.x + it.w + WORD_GAP } ?: MARGIN_LEFT
                    if (on.isEmpty() || x + w <= right || line >= maxL) break
                } else {
                    val re = on.minOfOrNull { it.x - WORD_GAP } ?: right
                    x = re - w
                    if (on.isEmpty() || x >= MARGIN_LEFT || line >= maxL) break
                }
                line++
            }
            lines[page] = line
            return TextItem(System.nanoTime(), line, x, w, text, lineRtl, colorInt, TEXT_SIZE)
        }

        fun applyEdit(page: Int, item: TextItem, newText: String) {
            val list = texts[page] ?: return
            if (newText.isEmpty()) {
                texts[page] = list.filter { it.id != item.id }
            } else {
                val w = wDpOf(newText)
                texts[page] = list.map { if (it.id == item.id) it.copy(text = newText, w = w) else it }
            }
            reflow(page, item.line)
            saveCur(page)
        }

        fun runConversion() {
            if (!convert || pending.isEmpty() || pendingPage < 0) return
            val page = pendingPage
            val group = pending.toList()
            pending.clear()
            scope.launch {
                val tag = if (lang == "fa") "fa" else "en-US"
                var failed = false
                var errMsg = ""
                var downloading = false
                val langName = if (lang == "fa") "Persian" else "English"
                val text: String? = try {
                    Recognizer.recognize(tag, group.map { it.pts }) {
                        status = "Downloading model..."
                        sticky = true
                        downloading = true
                        ModelNotifier.show(
                            ctx, "Downloading handwriting model",
                            "$langName model is downloading. This can take a minute.",
                            true, android.R.drawable.stat_sys_download
                        )
                    }
                } catch (e: Exception) {
                    failed = true
                    errMsg = (e.message ?: e.javaClass.simpleName).take(500)
                    null
                }
                if (sticky) {
                    sticky = false
                    status = null
                }
                if (failed) {
                    status = "Model error: $errMsg"
                    ModelNotifier.show(
                        ctx, "Model download failed", errMsg, false, android.R.drawable.stat_notify_error
                    )
                    return@launch
                }
                if (downloading) {
                    ModelNotifier.show(
                        ctx, "Model ready", "$langName handwriting recognition now works offline.",
                        false, android.R.drawable.stat_sys_download_done
                    )
                }
                val word = text?.trim()
                if (word.isNullOrEmpty()) {
                    status = "Couldn't read that"
                    return@launch
                }
                var minX = Float.MAX_VALUE
                var maxX = -Float.MAX_VALUE
                var minY = Float.MAX_VALUE
                var maxY = -Float.MAX_VALUE
                group.forEach { s ->
                    var i = 0
                    while (i + 1 < s.pts.size) {
                        minX = min(minX, s.pts[i]); maxX = max(maxX, s.pts[i])
                        minY = min(minY, s.pts[i + 1]); maxY = max(maxY, s.pts[i + 1])
                        i += 2
                    }
                }
                val colorInt = Color(group.first().color).copy(alpha = 1f).toArgb()
                ink[page] = (ink[page] ?: emptyList()).filter { s -> group.none { it === s } }
                val item = placeWord(page, word, colorInt)
                texts[page] = (texts[page] ?: emptyList()) + item
                saveCur(page)
                conv = ConvState(page, item.id, Offset((minX + maxX) / 2f, (minY + maxY) / 2f), group)
                scope.launch {
                    convT.snapTo(0f)
                    convT.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
                    conv = null
                }
            }
        }

        LaunchedEffect(tick) {
            delay(900)
            while (touching) delay(100)
            runConversion()
        }

        fun nextLine() {
            val p = fv.roundToInt().coerceIn(0, n - 1)
            val maxL = lineCount(hDp) - 1
            val l = lines[p] ?: 0
            if (l < maxL) {
                lines[p] = l + 1
                saveCur(p)
            } else if (p < n - 1) {
                lines[p + 1] = 0
                goTo((p + 1).toFloat())
            } else {
                onAddPage()
            }
        }

        // pages
        if (flip.value > 0f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(n, writeMode, pencil, convert) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            val w = size.width.toFloat()
                            val edgeZone = if (writeMode) 28.dp.toPx() else w * 0.25f
                            val edge = down.position.x < edgeZone || down.position.x > w - edgeZone
                            if (!writeMode || edge) {
                                // page flip gesture
                                job?.cancel()
                                var acc = 0f
                                var dragging = false
                                val slop = 8.dp.toPx()
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!c.pressed) break
                                    val dx = c.positionChange().x
                                    if (dx != 0f) {
                                        acc += abs(dx)
                                        if (!dragging && acc > slop) dragging = true
                                        if (dragging) {
                                            c.consume()
                                            lastDir = if (dx < 0) 1 else -1
                                            fv = (fv - dx / w).coerceIn(0f, (n - 1).toFloat())
                                        }
                                    }
                                }
                                if (dragging) {
                                    settle(lastDir)
                                } else if (down.position.x > w - edgeZone) {
                                    goTo(min(floor(fv) + 1f, (n - 1).toFloat()))
                                } else if (down.position.x < edgeZone) {
                                    goTo(max(ceil(fv) - 1f, 0f))
                                }
                            } else {
                                // writing gesture
                                val d = density.density
                                val page = fv.roundToInt().coerceIn(0, n - 1)
                                sound.pencil = pencil
                                touching = true
                                live.clear()
                                live.add(down.position.x / d)
                                live.add(down.position.y / d)
                                var prevPos = down.position
                                var prevT = down.uptimeMillis
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!c.pressed) {
                                        c.consume()
                                        break
                                    }
                                    if (c.position != prevPos) {
                                        c.consume()
                                        live.add(c.position.x / d)
                                        live.add(c.position.y / d)
                                        val dt = max(1L, c.uptimeMillis - prevT).toFloat()
                                        val dist = (c.position - prevPos).getDistance()
                                        sound.target = (dist / dt / 1.5f).coerceIn(0f, 1f)
                                        prevPos = c.position
                                        prevT = c.uptimeMillis
                                    }
                                }
                                val pts = live.toFloatArray()
                                live.clear()
                                touching = false
                                if (pts.isNotEmpty()) {
                                    // a short tap on converted text opens the editor
                                    var travel = 0f
                                    var i = 2
                                    while (i + 1 < pts.size) {
                                        val ddx = pts[i] - pts[i - 2]
                                        val ddy = pts[i + 1] - pts[i - 1]
                                        travel += sqrt(ddx * ddx + ddy * ddy)
                                        i += 2
                                    }
                                    if (travel < 6f) {
                                        val px = pts[0]
                                        val py = pts[1]
                                        val hit = (texts[page] ?: emptyList()).firstOrNull { t ->
                                            val yb = LINE_TOP + t.line * LINE_H
                                            px >= t.x - 4f && px <= t.x + t.w + 4f && py >= yb - LINE_H && py <= yb
                                        }
                                        if (hit != null) {
                                            editing = Pair(page, hit)
                                            return@awaitEachGesture
                                        }
                                    }
                                    val stroke = InkStroke(inkColor.toArgb(), inkWidth, pts)
                                    ink[page] = (ink[page] ?: emptyList()) + stroke
                                    saveCur(page)
                                    if (convert) {
                                        if (pendingPage != page) {
                                            pending.clear()
                                            pendingPage = page
                                        }
                                        pending.add(stroke)
                                        tick++
                                    }
                                }
                            }
                        }
                    }
            ) {
                val start = fv.toInt()
                val fr = fv - start
                listOf(start + 1, start).filter { it in 0 until n }.forEach { k ->
                    key(k) {
                        val r = (fv - k).coerceIn(0f, 1f)
                        val shade = if (k == start) 0.35f * fr else 0.8f * fr * (1f - fr)
                        val cv = conv
                        PageSheet(
                            shade = shade,
                            strokes = ink[k] ?: emptyList(),
                            texts = texts[k] ?: emptyList(),
                            conv = if (cv != null && cv.page == k) cv else null,
                            convProgress = { convT.value },
                            live = if (k == cur) live else null,
                            liveColor = inkColor,
                            liveWidth = inkWidth,
                            activeLine = lines[k] ?: 0,
                            modifier = Modifier.graphicsLayer {
                                rotationY = -180f * r
                                cameraDistance = 20f * density.density
                                transformOrigin = TransformOrigin(0f, 0.5f)
                                alpha = if (r > 0.5f) 0f else 1f
                            }
                        )
                    }
                }
            }
        }

        // cover (flies out of the shelf, then swings open)
        if (flip.value < 1f) {
            val e = expand.value
            val l = lerpF(from.left, 0f, e)
            val t = lerpF(from.top, 0f, e)
            val w = lerpF(from.width, wPx, e)
            val h = lerpF(from.height, hPx, e)
            CoverFace(
                nb.title, color,
                Modifier
                    .offset { IntOffset(l.roundToInt(), t.roundToInt()) }
                    .size(with(density) { w.toDp() }, with(density) { h.toDp() })
                    .graphicsLayer {
                        rotationY = -165f * flip.value
                        cameraDistance = 24f * density.density
                        transformOrigin = TransformOrigin(0f, 0.5f)
                        alpha = if (flip.value * 165f > 90f) 0f else 1f
                    }
                    .clip(RoundedCornerShape(lerpF(6f, 0f, e).dp)),
                textSize = lerpF(16f, 30f, e)
            )
        }

        // top bar
        val page = min((fv + 0.5f).toInt() + 1, n)
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp)
                .height(48.dp)
                .graphicsLayer { alpha = flip.value },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(48.dp).clickable { close() }, contentAlignment = Alignment.Center) {
                Text("\u2039", fontSize = 32.sp, color = Color(0x99000000))
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text("$page / $n", fontSize = 13.sp, color = Color(0x99000000))
            }
            Box(Modifier.size(48.dp).clickable { onAddPage() }, contentAlignment = Alignment.Center) {
                Text("+", fontSize = 26.sp, color = Color(0x99000000))
            }
        }

        // status message
        val st = status
        if (st != null) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xE62B2622))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(st, fontSize = 12.sp, color = PAPER)
            }
        }

        // bottom tool bar
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
                .graphicsLayer { alpha = flip.value }
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xF2FFFFFF))
                .border(0.5.dp, Color(0x22000000), RoundedCornerShape(24.dp))
                .padding(horizontal = 6.dp, vertical = 5.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Seg("Write", "Flip", writeMode) { writeMode = it }
                Seg("Pencil", "Pen", pencil) { pencil = it }
                Seg("FA", "EN", lang == "fa") { lang = if (it) "fa" else "en" }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                BarButton("Undo") { undo() }
                TogglePill("Convert", convert) { convert = !convert }
                BarButton("Next line") { nextLine() }
            }
        }

        // edit converted text
        editing?.let { ed ->
            val pg = ed.first
            val item = ed.second
            var txt by remember(item.id) { mutableStateOf(item.text) }
            AlertDialog(
                onDismissRequest = { editing = null },
                title = { Text("Edit text") },
                text = { OutlinedTextField(value = txt, onValueChange = { txt = it }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        applyEdit(pg, item, txt.trim())
                        editing = null
                    }) { Text("Save") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            applyEdit(pg, item, "")
                            editing = null
                        }) { Text("Delete") }
                        TextButton(onClick = { editing = null }) { Text("Cancel") }
                    }
                }
            )
        }
    }
}
